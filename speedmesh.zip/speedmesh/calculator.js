// ==========================================
// 🔮 MESH Grade Calculator (v2.0 - С учетом веса)
// ==========================================
(function() {
    console.log("🔮 [Калькулятор] Загружен. Учет веса оценок активен.");

    let tooltip = null;

    function createTooltip() {
        if (tooltip) return;
        tooltip = document.createElement('div');
        tooltip.id = 'mesh-grade-calculator';
        tooltip.style.cssText = `
            position: absolute; background: rgba(15, 23, 42, 0.95); color: #fff;
            padding: 10px 14px; border-radius: 8px; border-left: 4px solid #8b5cf6;
            font-family: 'Inter', sans-serif; font-size: 12px; z-index: 9999999;
            pointer-events: none; box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            backdrop-filter: blur(5px); opacity: 0; transition: opacity 0.2s; white-space: nowrap;
        `;
        document.body.appendChild(tooltip);
    }

    // Формула с учетом весов
    function calculateNeeded(currentAvg, totalWeight, targetAvg, gradeValue) {
        let currentSum = currentAvg * totalWeight;
        let needed = (targetAvg * totalWeight - currentSum) / (gradeValue - targetAvg);
        return Math.ceil(needed);
    }

    function showTooltip(e, avgStr, row) {
        let avg = parseFloat(avgStr.replace(',', '.'));
        if (isNaN(avg)) return;

        let marks = row.querySelectorAll('[data-test-component*="markCell-"], .mark-text');
        let totalWeight = 0; // Теперь мы считаем не количество оценок, а их СУММАРНЫЙ ВЕС

        marks.forEach(m => { 
            let text = m.innerText.trim();
            // Заменяем маленькие юникод-цифры (индексы) на обычные
            text = text.replace(/[₁₂₃₄₅₆₇₈₉]/g, char => '123456789'['₁₂₃₄₅₆₇₈₉'.indexOf(char)]);
            
            // Ищем оценку (2-5) и возможный вес после неё (любая цифра)
            let match = text.match(/([2345])\s*(\d)?/);
            if (match) {
                let weight = match[2] ? parseInt(match[2]) : 1;
                totalWeight += weight;
            }
        });

        // Защита: если оценок нет, берем примерное значение (10)
        if (totalWeight === 0) totalWeight = 10; 

        let text = `<div style="font-weight:bold; margin-bottom:6px; color:#8b5cf6;">🔮 Прогноз оценок</div>`;
        
        if (avg >= 4.5) {
            text += `🏆 <b>Уже отлично!</b> (Пятёрка в кармане)`;
        } else if (avg >= 3.5 && avg < 4.5) {
            let fives = calculateNeeded(avg, totalWeight, 4.5, 5);
            text += `До твердой <b>"5"</b> нужно: <b>${fives}</b> пятёрок<br>`;
            text += `<span style="color:#94a3b8; font-size:10px;">(Суммарный вес оценок: ${totalWeight})</span>`;
        } else if (avg >= 2.5 && avg < 3.5) {
            let fours = calculateNeeded(avg, totalWeight, 3.5, 4);
            let fives = calculateNeeded(avg, totalWeight, 3.5, 5);
            text += `До <b>"4"</b> нужно: <b>${fives}</b> пятёрок ИЛИ <b>${fours}</b> четвёрок<br>`;
            text += `<span style="color:#94a3b8; font-size:10px;">(Суммарный вес оценок: ${totalWeight})</span>`;
        } else {
            let threes = calculateNeeded(avg, totalWeight, 2.5, 3);
            text += `Для спасения на <b>"3"</b> нужно: <b>${threes}</b> троек (или выше)<br>`;
            text += `<span style="color:#94a3b8; font-size:10px;">(Суммарный вес оценок: ${totalWeight})</span>`;
        }

        tooltip.innerHTML = text;
        tooltip.style.opacity = '1';
        
        // Умное позиционирование
        const rect = e.target.getBoundingClientRect();
        let topPos = window.scrollY + rect.top - tooltip.offsetHeight - 10;
        let leftPos = window.scrollX + rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2);

        if (leftPos + tooltip.offsetWidth > window.innerWidth - 20) leftPos = window.innerWidth - tooltip.offsetWidth - 20;
        if (leftPos < 20) leftPos = 20;
        if (topPos < window.scrollY + 20) topPos = window.scrollY + rect.bottom + 10;

        tooltip.style.top = topPos + 'px';
        tooltip.style.left = leftPos + 'px';
    }

    function hideTooltip() { if (tooltip) tooltip.style.opacity = '0'; }

    function attachListeners() {
        createTooltip();
        const cells = document.querySelectorAll('span, div, td');
        cells.forEach(cell => {
            if (cell.dataset.calcAttached) return;
            let text = cell.innerText.trim();
            if (/^\d[.,]\d{2}$/.test(text) && cell.closest('tr')) { 
                cell.dataset.calcAttached = "true";
                cell.style.cursor = "help";
                cell.style.borderBottom = "1px dashed #8b5cf6";
                cell.addEventListener('mouseenter', (e) => showTooltip(e, text, cell.closest('tr')));
                cell.addEventListener('mouseleave', hideTooltip);
            }
        });
    }

    setInterval(attachListeners, 3000); 
})();