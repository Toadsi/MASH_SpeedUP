// ==========================================
// 🎲 MESH Randomizer (v4.6 - Original Logic + New UI)
// ==========================================
(function() {
    console.log("🎲 MESH Randomizer: Логика восстановлена, интерфейс обновлен");

    let isSpinning = false;
    let isEnabled = true;

    // Синхронизация с настройками
    chrome.storage.sync.get(['randomizerMode'], (data) => {
        if (data && data.randomizerMode !== undefined) isEnabled = data.randomizerMode;
        init();
    });

    function getStudents() {
        const rows = Array.from(document.querySelectorAll('tr')).filter(r => r.innerText.includes(' '));
        let list = [];

        rows.forEach(row => {
            const nameCell = row.querySelector('td:first-child, .student-name');
            if (!nameCell) return;
            
            const name = nameCell.innerText.trim();
            if (name.length < 5 || !name.includes(' ')) return;

            // Сбор оценок для веса
            const grades = Array.from(row.querySelectorAll('span'))
                .map(s => parseInt(s.innerText))
                .filter(n => !isNaN(n) && n >= 2 && n <= 5);

            let weight = 5;
            if (grades.length > 0) {
                const avg = grades.reduce((a, b) => a + b, 0) / grades.length;
                weight = Math.max(1, Math.min(10, (6 - avg) * 2));
            }

            list.push({ name, weight, avg: grades.length ? (grades.reduce((a,b)=>a+b,0)/grades.length).toFixed(1) : "—" });
        });
        return list;
    }

    function weightedRandom(students) {
        let total = students.reduce((s, st) => s + st.weight, 0);
        let r = Math.random() * total;
        for (let s of students) {
            if (r < s.weight) return s;
            r -= s.weight;
        }
        return students[0];
    }

    function showWinner(winner) {
        if (document.getElementById('mesh-rand-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'mesh-rand-overlay';
        overlay.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.75); backdrop-filter: blur(12px);
            z-index: 10000; display: flex; align-items: center; justify-content: center;
            opacity: 0; transition: opacity 0.4s ease;
        `;

        overlay.innerHTML = `
            <div style="background: #121212; border: 1px solid #333; padding: 40px; border-radius: 28px; text-align: center; color: white; font-family: 'Segoe UI', system-ui, sans-serif; box-shadow: 0 25px 50px rgba(0,0,0,0.6); max-width: 400px; width: 90%;">
                <div style="font-size: 12px; color: #3b82f6; font-weight: bold; text-transform: uppercase; letter-spacing: 3px; margin-bottom: 15px;">Случайный выбор</div>
                <div id="mesh-rand-name" style="font-size: 26px; font-weight: 700; margin-bottom: 10px; min-height: 40px;">Кого же...</div>
                <div id="mesh-rand-info" style="font-size: 14px; color: #888; margin-bottom: 30px; opacity: 0; transition: 0.5s;">
                </div>
                <button id="mesh-rand-close" style="background: #3b82f6; color: white; border: none; padding: 14px 45px; border-radius: 14px; font-size: 16px; font-weight: 600; cursor: pointer; opacity: 0; transition: 0.3s;">Закрыть</button>
            </div>
        `;

        document.body.appendChild(overlay);
        setTimeout(() => overlay.style.opacity = '1', 50);

        const nameEl = document.getElementById('mesh-rand-name');
        let i = 0;
        const interval = setInterval(() => {
            nameEl.innerText = ["⏳", "🔍", "🎲", "🎯"][i % 4] + " Ищем...";
            if (++i > 15) {
                clearInterval(interval);
                nameEl.innerText = winner.name;
                document.getElementById('mesh-rand-info').style.opacity = '1';
                document.getElementById('mesh-rand-close').style.opacity = '1';
            }
        }, 80);

        document.getElementById('mesh-rand-close').onclick = () => {
            overlay.style.opacity = '0';
            setTimeout(() => overlay.remove(), 400);
        };
    }

    function createMainButton() {
        if (!isEnabled || document.getElementById('mesh-randomizer-btn')) return;

        const btn = document.createElement('button');
        btn.id = 'mesh-randomizer-btn';
        btn.innerHTML = '🎲 Кого спросить?';
        btn.style.cssText = `
            position: fixed; bottom: 30px; left: 30px; z-index: 9999;
            background: rgba(20, 20, 20, 0.85); backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1); color: white;
            padding: 14px 28px; border-radius: 16px; cursor: pointer;
            font-weight: 600; font-size: 15px; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        `;

        btn.onmouseover = () => {
            btn.style.background = 'rgba(40, 40, 40, 0.95)';
            btn.style.transform = 'translateY(-3px) scale(1.02)';
            btn.style.boxShadow = '0 15px 40px rgba(0,0,0,0.5)';
        };
        btn.onmouseout = () => {
            btn.style.transform = 'translateY(0) scale(1)';
            btn.style.background = 'rgba(20, 20, 20, 0.85)';
        };

        btn.onclick = () => {
            const students = getStudents();
            if (students.length === 0) {
                alert("Ученики не найдены. Попробуйте обновить страницу или зайти в журнал.");
                return;
            }
            showWinner(weightedRandom(students));
        };

        document.body.appendChild(btn);
    }

    function init() {
        if (document.readyState === 'complete') createMainButton();
        else window.addEventListener('load', createMainButton);
        
        const observer = new MutationObserver(createMainButton);
        observer.observe(document.body, { childList: true, subtree: true });
    }

    chrome.runtime.onMessage.addListener((req) => {
        if (req.action === "updateSettings") {
            isEnabled = req.settings.randomizerMode;
            const b = document.getElementById('mesh-randomizer-btn');
            if (b) b.style.display = isEnabled ? 'block' : 'none';
        }
    });
})();