// ==========================================
// ⏳ MESH Timer (Умный формат времени + Рабочая суббота)
// ==========================================
(function() {
    console.log("⏳ MESH Timer: Обновлен формат времени (Ч:ММ при >60 мин)");

    let isEnabled = true;

    chrome.storage.sync.get(['timerMode'], (data) => {
        if (data && data.timerMode !== undefined) isEnabled = data.timerMode;
    });

    chrome.runtime.onMessage.addListener((req) => {
        if (req.action === "updateSettings" && req.settings.timerMode !== undefined) {
            isEnabled = req.settings.timerMode;
            const card = document.getElementById('mesh-timer-card');
            if (card) card.style.display = isEnabled ? 'flex' : 'none';
        }
    });

    // Расписание
    const scheduleData = {
        default: [
            { type: 'lesson', start: '09:00', end: '09:45', title: '1 Урок' },
            { type: 'break',  start: '09:45', end: '09:55', title: 'Перемена' },
            { type: 'lesson', start: '09:55', end: '10:40', title: '2 Урок' },
            { type: 'break',  start: '10:40', end: '11:00', title: 'Перемена' },
            { type: 'lesson', start: '11:00', end: '11:45', title: '3 Урок' },
            { type: 'break',  start: '11:45', end: '12:05', title: 'Перемена' },
            { type: 'lesson', start: '12:05', end: '12:50', title: '4 Урок' },
            { type: 'break',  start: '12:50', end: '13:10', title: 'Перемена' },
            { type: 'lesson', start: '13:10', end: '13:55', title: '5 Урок' },
            { type: 'break',  start: '13:55', end: '14:15', title: 'Перемена' },
            { type: 'lesson', start: '14:15', end: '15:00', title: '6 Урок' },
            { type: 'break',  start: '15:00', end: '15:10', title: 'Перемена' },
            { type: 'lesson', start: '15:10', end: '15:55', title: '7 Урок' },
            { type: 'break',  start: '15:55', end: '16:15', title: 'Перемена' },
            { type: 'lesson', start: '16:15', end: '17:00', title: '8 Урок' },
            { type: 'break',  start: '17:00', end: '17:10', title: 'Перемена' },
            { type: 'lesson', start: '17:10', end: '17:55', title: '9 Урок' },
            { type: 'break',  start: '17:55', end: '18:05', title: 'Перемена' },
            { type: 'lesson', start: '18:05', end: '18:50', title: '10 Урок' },
            { type: 'break',  start: '18:50', end: '19:00', title: 'Перемена' },
            { type: 'lesson', start: '19:00', end: '19:45', title: '11 Урок' },
            { type: 'break',  start: '19:45', end: '19:55', title: 'Перемена' },
            { type: 'lesson', start: '19:55', end: '20:40', title: '12 Урок' }
        ]
    };

    function getMinutes(timeStr) {
        const [h, m] = timeStr.split(':').map(Number);
        return h * 60 + m;
    }

    function pad(n) { return n < 10 ? '0' + n : n; }

    /**
     * Форматирует оставшееся время
     * Если > 60 мин: H:MM
     * Если < 60 мин: MM:SS
     */
    function formatRemainingTime(seconds) {
        const totalMinutes = Math.floor(seconds / 60);
        if (totalMinutes >= 60) {
            const h = Math.floor(totalMinutes / 60);
            const m = totalMinutes % 60;
            return `${h}:${pad(m)}`;
        } else {
            const m = totalMinutes;
            const s = seconds % 60;
            return `${pad(m)}:${pad(s)}`;
        }
    }

    function update() {
        const now = new Date();
        const currentMins = now.getHours() * 60 + now.getMinutes();
        const currentSecs = now.getSeconds();

        const elTime = document.getElementById('mt-time');
        const elInfo = document.getElementById('mt-info');
        const elBar = document.getElementById('mt-progress-bar');
        const elDot = document.getElementById('mt-progress-dot');

        if (!elTime || !isEnabled) return;

        const day = now.getDay();
        // Суббота (6) теперь рабочая. Выходной только в воскресенье (0)
        if (day === 0) {
            elTime.textContent = "--:--";
            elInfo.textContent = "Воскресенье";
            elBar.style.width = '0%';
            return;
        }

        const data = scheduleData.default;
        let activeFound = false;

        for (const item of data) {
            const start = getMinutes(item.start);
            const end = getMinutes(item.end);

            if (currentMins >= start && currentMins < end) {
                activeFound = true;
                const totalSec = (end - start) * 60;
                const elapsedSec = (currentMins - start) * 60 + currentSecs;
                const remainingSec = totalSec - elapsedSec;

                elTime.textContent = formatRemainingTime(remainingSec);
                
                const percent = (elapsedSec / totalSec) * 100;
                elBar.style.width = `${percent}%`;

                if (item.type === 'break') {
                    elInfo.textContent = "Перемена";
                    elDot.style.background = '#f59e0b'; 
                    elDot.style.boxShadow = '0 0 8px #f59e0b';
                    elBar.style.background = 'rgba(245, 158, 11, 0.3)';
                } else {
                    elInfo.textContent = item.title;
                    elDot.style.background = (remainingSec < 300) ? '#ef4444' : '#10b981';
                    elDot.style.boxShadow = (remainingSec < 300) ? '0 0 8px #ef4444' : '0 0 8px #10b981';
                    elBar.style.background = 'rgba(16, 185, 129, 0.3)';
                }
                break;
            }
        }

        if (!activeFound) {
            const firstStart = getMinutes(data[0].start);
            const lastEnd = getMinutes(data[data.length - 1].end);

            if (currentMins < firstStart) {
                const diffSecTotal = (firstStart - currentMins) * 60 - currentSecs;
                elTime.textContent = formatRemainingTime(diffSecTotal);
                elInfo.textContent = "До начала";
                elBar.style.width = '100%'; 
                elDot.style.background = '#3b82f6';
                elDot.style.boxShadow = '0 0 8px #3b82f6';
            } else {
                elTime.textContent = "00:00";
                elInfo.textContent = "Учёба окончена";
                elBar.style.width = '100%';
                elDot.style.background = '#6b7280';
                elDot.style.boxShadow = 'none';
            }
        }
    }

    function initUI() {
        if (document.getElementById('mesh-timer-card')) return;

        const card = document.createElement('div');
        card.id = 'mesh-timer-card';
        card.style = `
            position: fixed; bottom: 20px; right: 20px; z-index: 9999;
            width: 140px; background: #111827; color: white; border-radius: 12px;
            padding: 12px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; 
            display: flex; flex-direction: column;
            box-shadow: 0 10px 25px rgba(0,0,0,0.5); cursor: move; user-select: none;
            border: 1px solid rgba(255,255,255,0.05);
        `;
        
        card.innerHTML = `
            <div id="mt-info" style="font-size: 10px; color: #9ca3af; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.05em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">Загрузка...</div>
            <div id="mt-time" style="font-size: 28px; font-weight: 800; font-variant-numeric: tabular-nums; line-height: 1.1;">00:00</div>
            <div style="width: 100%; height: 4px; background: rgba(255,255,255,0.1); border-radius: 2px; margin-top: 10px; position: relative; overflow: hidden;">
                <div id="mt-progress-bar" style="height: 100%; width: 0%; background: #10b981; border-radius: 2px; transition: width 1s linear;"></div>
                <div id="mt-progress-dot" style="position: absolute; right: 0; top: 0; bottom: 0; width: 4px; background: #10b981; transition: background 0.3s, box-shadow 0.3s;"></div>
            </div>
        `;

        document.body.appendChild(card);
        
        card.onmousedown = (e) => {
            let shiftX = e.clientX - card.getBoundingClientRect().left;
            let shiftY = e.clientY - card.getBoundingClientRect().top;
            
            function moveAt(pageX, pageY) {
                card.style.left = pageX - shiftX + 'px';
                card.style.top = pageY - shiftY + 'px';
                card.style.bottom = 'auto'; 
                card.style.right = 'auto';
            }

            function onMouseMove(e) {
                moveAt(e.pageX, e.pageY);
            }

            document.addEventListener('mousemove', onMouseMove);
            
            document.onmouseup = () => {
                document.removeEventListener('mousemove', onMouseMove);
                document.onmouseup = null;
            };
        };

        card.ondragstart = () => false;
    }

    initUI();
    setInterval(update, 1000);
    update();

})();