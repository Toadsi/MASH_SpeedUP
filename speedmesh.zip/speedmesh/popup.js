// ==========================================
// ⚙️ MESH Core: Логика меню (Без радара)
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    const toggles = [
        'autoGrader', 'highlightGrades', 'ktpModule', 'calcAttendance', 
        'speedUp', 'spyMode', 'architectMode', 'randomizerMode', 
        'timerMode', 'birthdayMode', 'homeworkMode'
    ];

    const uiElements = {};
    toggles.forEach(key => { uiElements[key] = document.getElementById(key); });

    // --- 1. ЗАГРУЗКА НАСТРОЕК ---
    chrome.storage.sync.get(toggles, (data) => {
        toggles.forEach(key => {
            if (uiElements[key]) {
                const defaultState = ['speedUp', 'spyMode', 'architectMode', 'homeworkMode'].includes(key) ? false : true;
                uiElements[key].checked = data[key] !== undefined ? data[key] : defaultState;
            }
        });
    });

    function showToast(text = "✅ Сохранено!") {
        const toast = document.getElementById('toast');
        toast.innerHTML = text;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 1500);
    }

    function notifyContentScript(message) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].url.includes('mos.ru')) {
                chrome.tabs.sendMessage(tabs[0].id, message).catch(() => {});
            }
        });
    }

    // --- 2. АВТОСОХРАНЕНИЕ ТУМБЛЕРОВ ---
    toggles.forEach(key => {
        if (uiElements[key]) {
            uiElements[key].addEventListener('change', (e) => {
                const isChecked = e.target.checked;
                chrome.storage.sync.set({ [key]: isChecked }, showToast);
                notifyContentScript({ action: 'updateSettings', settings: { [key]: isChecked } });
            });
        }
    });

    // --- УТИЛИТЫ И КНОПКИ ---
    document.getElementById('resetArchBtn')?.addEventListener('click', () => {
        if (confirm('Внимание! Это удалит все скрытые элементы. Продолжить?')) {
            notifyContentScript({ action: 'resetDesign' });
            showToast("✅ Дизайн сброшен");
        }
    });

    document.getElementById('btn-guide')?.addEventListener('click', () => { 
        chrome.tabs.create({ url: chrome.runtime.getURL("guide.html") }); 
    });
    
    document.getElementById('btn-trophies')?.addEventListener('click', () => { 
        notifyContentScript({ action: 'showTrophies' }); 
    });
});