// ==========================================
// 🕵️‍♂️ MESH API SPY v3 (Шпион + Локатор Куратора)
// ==========================================
(function() {
    if (window._meshApiSpyInjected) return; // Защита от двойного запуска
    window._meshApiSpyInjected = true;

    const originalFetch = window.fetch;
    let apiLog = {};

    // Восстанавливаем старый лог
    try {
        const existing = window.sessionStorage.getItem('MESH_API_DUMP');
        if (existing) apiLog = JSON.parse(existing);
    } catch(e) {}

    // Глобальный перехватчик
    window.fetch = async function(...args) {
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');
        const method = args[1] && args[1].method ? args[1].method.toUpperCase() : 'GET';

        // --- 1. ЛОКАТОР ДЛЯ РАДАРА КУРАТОРА (Работает всегда, невидимо) ---
        if (url) {
            let match = url.match(/(?:class_unit_id|group_ids|group_id)=([\d]+)/);
            if (match && !url.includes('attendance_notifications')) {
                window.postMessage({ type: 'MESH_RADAR_ID', id: match[1] }, '*');
            }
        }
        // -----------------------------------------------------------------

        const response = await originalFetch.apply(this, args);
        
        // --- 2. ЛОГИКА ПАНЕЛИ ШПИОНА (Если тумблер включен) ---
        if (window.sessionStorage.getItem('MESH_SPY_ENABLED') === 'true') {
            if (url.includes('/api/')) { 
                try {
                    const clone = response.clone();
                    clone.json().then(data => {
                        const shortUrl = url.split('?')[0].replace(/\/\d+/g, '/{id}');
                        const key = `[${method}] ${shortUrl}`;

                        if (!apiLog[key]) {
                            apiLog[key] = data;
                            window.sessionStorage.setItem('MESH_API_DUMP', JSON.stringify(apiLog));
                            updateRecordCount();
                        }
                    }).catch(() => {}); 
                } catch(e) {}
            }
        }
        return response;
    };

    // --- ИНТЕРФЕЙС ПАНЕЛИ ШПИОНА ---
    let spyPanel = null;

    function drawSpyPanel() {
        if (spyPanel) return;
        spyPanel = document.createElement('div');
        spyPanel.id = 'mesh-spy-panel';
        spyPanel.style.cssText = "position:fixed; bottom:20px; right:20px; z-index:9999999; background:rgba(26, 26, 27, 0.95); border: 1px solid #9b59b6; color:white; padding:12px; border-radius:10px; display:flex; flex-direction:column; gap:10px; box-shadow: 0 5px 20px rgba(0,0,0,0.7); backdrop-filter: blur(5px); transition: 0.3s; font-family: sans-serif;";
        
        let title = document.createElement('div');
        title.id = 'mesh-spy-title';
        title.innerHTML = `🕵️‍♂️ Шпион активен <br><span style="font-size:10px; color:#bdc3c7;">Поймано пакетов: </span><span id="mesh-spy-count" style="color:#2ecc71; font-weight:bold;">${Object.keys(apiLog).length}</span>`;
        title.style.cssText = "font-size:13px; font-weight:bold; color:#9b59b6; text-align:center; padding-bottom:6px; border-bottom:1px solid rgba(255,255,255,0.1); line-height:1.4;";
        spyPanel.appendChild(title);

        let btnWrap = document.createElement('div');
        btnWrap.style.cssText = "display:flex; gap:6px; justify-content:center;";

        let dlBtn = document.createElement('button');
        dlBtn.innerHTML = "💾 Скачать";
        dlBtn.style.cssText = "background:#8e44ad; color:white; border:none; padding:7px 12px; border-radius:6px; cursor:pointer; font-weight:bold; font-size:12px; transition:0.2s;";
        dlBtn.onmouseover = () => dlBtn.style.background = "#9b59b6";
        dlBtn.onmouseout = () => dlBtn.style.background = "#8e44ad";
        dlBtn.onclick = () => {
            if (Object.keys(apiLog).length === 0) return alert("Лог пуст! Выполните какие-нибудь действия на сайте.");
            const blob = new Blob([JSON.stringify(apiLog, null, 4)], { type: 'application/json' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = `MESH_SpyLog_${new Date().toISOString().slice(0,10)}.json`;
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
        };
        
        let clearBtn = document.createElement('button');
        clearBtn.innerHTML = "🗑️ Сброс";
        clearBtn.style.cssText = "background:#e74c3c; color:white; border:none; padding:7px 12px; border-radius:6px; cursor:pointer; font-weight:bold; font-size:12px; transition:0.2s;";
        clearBtn.onmouseover = () => clearBtn.style.background = "#c0392b";
        clearBtn.onmouseout = () => clearBtn.style.background = "#e74c3c";
        clearBtn.onclick = () => {
            apiLog = {};
            window.sessionStorage.removeItem('MESH_API_DUMP');
            updateRecordCount();
        };

        btnWrap.appendChild(dlBtn);
        btnWrap.appendChild(clearBtn);
        spyPanel.appendChild(btnWrap);
        document.body.appendChild(spyPanel);
    }

    function updateRecordCount() {
        let c = document.getElementById('mesh-spy-count');
        if (c) c.innerText = Object.keys(apiLog).length;
    }

    function checkPanelVisibility() {
        const isEnabled = window.sessionStorage.getItem('MESH_SPY_ENABLED') === 'true';
        if (isEnabled) {
            drawSpyPanel();
            spyPanel.style.display = 'flex';
        } else if (spyPanel) spyPanel.style.display = 'none';
    }

    window.addEventListener('MESH_SPY_TOGGLE', checkPanelVisibility);
    
    let initIvl = setInterval(() => {
        if (document.body) {
            clearInterval(initIvl);
            checkPanelVisibility();
        }
    }, 500);
})();