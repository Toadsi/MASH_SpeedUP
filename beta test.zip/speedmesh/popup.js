document.addEventListener('DOMContentLoaded', () => {
    const inputs = document.querySelectorAll('input[type="checkbox"]');

    chrome.storage.sync.get(null, (data) => {
        inputs.forEach(input => {
            if (data[input.id] !== undefined) input.checked = data[input.id];
            else input.checked = !(input.id === 'architectMode' || input.id === 'speedUp' || input.id === 'apiSpyMode');
        });
    });

    inputs.forEach(input => {
        input.addEventListener('change', (e) => {
            let settingToSave = {}; settingToSave[e.target.id] = e.target.checked;
            chrome.storage.sync.set(settingToSave, () => {
                chrome.storage.sync.get(null, (allSettings) => {
                    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                        if (tabs[0]) {
                            chrome.tabs.sendMessage(tabs[0].id, {action: "updateSettings", settings: allSettings});
                            if (e.target.id === 'architectMode') chrome.tabs.sendMessage(tabs[0].id, {action: "toggleArchitect", state: e.target.checked});
                        }
                    });
                });
            });
        });
    });

    document.getElementById('saveBtn').onclick = () => { chrome.tabs.query({active: true, currentWindow: true}, (tabs) => { if (tabs[0]) { chrome.tabs.reload(tabs[0].id); window.close(); } }); };
    document.getElementById('resetDesignBtn').onclick = () => { if (confirm("Сбросить изменения Архитектора?")) { chrome.tabs.query({active: true, currentWindow: true}, (tabs) => { if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, {action: "resetDesign"}); }); } };

    // ==========================================
    // ЛОГИКА ЗАЛА СЛАВЫ (105 АЧИВОК)
    // ==========================================
    const BADGES = {
        'first_blood': { i: '🩸', t: 'Первая Кровь', d: 'Выставили первую авто-оценку.' },
        'novice': { i: '🌱', t: 'Новичок', d: 'Поставили 10 авто-оценок за всё время.' },
        'pro': { i: '🦾', t: 'Кибер-Препод', d: 'Поставили 50 авто-оценок. Вы втягиваетесь!' },
        'terminator': { i: '🤖', t: 'Терминатор', d: '100 оценок! Машина по выставлению баллов.' },
        'god': { i: '👑', t: 'Бог Журнала', d: '500 авто-оценок. Сервер МЭШ молится на вас.' },
        'cyborg': { i: '🦿', t: 'Киборг', d: 'Поставили 1000 авто-оценок. Вы забыли, как писать ручкой.' },
        'matrix': { i: '🕶️', t: 'Архитектор Матрицы', d: '5000 авто-оценок. Вы и есть МЭШ.' },
        'over_9000': { i: '💥', t: 'OVER 9000!', d: 'Более 9000 оценок. Ваш уровень запредельный!' },
        'three_axes': { i: '🎰', t: 'Три Топора', d: 'Выставили ровно 777 оценок за всё время.' },
        'devil': { i: '😈', t: 'Адский Труд', d: '666 авто-оценок за всё время.' },
        
        'owl': { i: '🦉', t: 'Ночной Дозор', d: 'Открыли МЭШ после полуночи (00:00 - 04:00).' },
        'vampire': { i: '🦇', t: 'Вампир', d: 'Глубокая ночь. Зашли с 02:00 до 03:00.' },
        'nightmare': { i: '🧛', t: 'Дракула', d: 'Зашли в МЭШ ровно в полночь (00:00).' },
        'sunrise': { i: '🌤️', t: 'Первые Лучи', d: 'Работаете на рассвете (с 05:00 до 06:00).' },
        'early_bird': { i: '🌅', t: 'Ранняя Пташка', d: 'Уже в журнале до 07:00 утра.' },
        'lunch_break': { i: '🍔', t: 'Без Обеда', d: 'Выставляете оценки с 13:00 до 14:00.' },
        'tea_time': { i: '🫖', t: 'Время Чая', d: 'Работаете ровно в 17:00.' },
        'overtime': { i: '🌃', t: 'Сверхурочные', d: 'Сидите в журнале после 20:00.' },
        'friday_party': { i: '🪩', t: 'Пятничный Вайб', d: 'Работаете в пятницу после 18:00.' },
        'weekend_warrior': { i: '⚔️', t: 'Трудоголик', d: 'Зашли в МЭШ в выходные.' },
        'monday': { i: '☠️', t: 'Тяжелый Понедельник', d: 'Зашли в МЭШ в понедельник до 10:00.' },
        
        'santa': { i: '🎅', t: 'Тайный Санта', d: 'Закрываете долги в декабре.' },
        'new_year': { i: '🥂', t: 'С Наступающим', d: 'Сидите в журнале 31 декабря.' },
        'grinch': { i: '🎄', t: 'Гринч', d: 'Работа в новогодние праздники (1-8 января).' },
        'student_day': { i: '🎓', t: 'Татьянин День', d: 'Работа в День студента (25 января).' },
        'valentines': { i: '💖', t: 'Любовь к Работе', d: 'Зашли в МЭШ 14 февраля.' },
        'defender': { i: '🪖', t: 'Защитник Журнала', d: 'Работаете 23 февраля.' },
        'womens_day': { i: '💐', t: 'Весенний Праздник', d: 'Работаете 8 марта.' },
        'pi_day': { i: '🥧', t: 'День Пи', d: 'Зашли в МЭШ 14 марта (3.14).' },
        'spring': { i: '🌸', t: 'Весеннее Обострение', d: 'Март-Апрель. Скоро сессия!' },
        'fool': { i: '🤡', t: 'День Дурака', d: 'Работа 1 апреля. Это не шутка?' },
        'cosmonaut': { i: '🚀', t: 'Поехали!', d: 'День космонавтики (12 апреля).' },
        'labor_day': { i: '🕊️', t: 'Мир, Труд, Май', d: 'Зашли в МЭШ 1 мая.' },
        'star_wars': { i: '☄️', t: 'Джедай', d: 'Зашли в МЭШ 4 мая (May the 4th).' },
        'victory': { i: '🎆', t: 'День Победы', d: 'Зашли в МЭШ 9 мая.' },
        'may_bugs': { i: '🐞', t: 'Майский Жук', d: 'Зашли в систему на майских праздниках.' },
        'summer': { i: '🏖️', t: 'Где мой отпуск?', d: 'Зашли в журнал летом.' },
        'knowledge': { i: '🔔', t: 'Снова в Школу', d: 'Работаете 1 сентября.' },
        'autumn': { i: '🍂', t: 'Снова в Бой', d: 'Сентябрь горит.' },
        'teachers_day': { i: '🧑‍🏫', t: 'Проф. Праздник', d: 'Зашли в МЭШ 5 октября (День Учителя).' },
        'halloween': { i: '🎃', t: 'Сладость/Гадость', d: 'Зашли в МЭШ 31 октября.' },
        'leap_year': { i: '🐸', t: 'Редкий Гость', d: '29 февраля. Бывает раз в 4 года.' },
        'lucky_13': { i: '🐈‍⬛', t: 'Пятница 13-е', d: 'Работаете в пятницу 13-го числа.' },

        'sniper': { i: '🎯', t: 'Снайпер', d: '15 успешных оценок за одну сессию.' },
        'machine_gun': { i: '🔫', t: 'Пулеметчик', d: '30 оценок за сессию.' },
        'centurion': { i: '💯', t: 'Центурион', d: '100 оценок за ОДНУ сессию. Монстр.' },
        'half_k': { i: '🪙', t: 'Полтысячи', d: '500 оценок за одну сессию. Рекорд!' },
        'good_cop': { i: '😇', t: 'Добрый Коп', d: 'Поставили пять «5» подряд!' },
        'executioner': { i: '🪓', t: 'Палач', d: 'Три «2» подряд.' },
        'hater': { i: '😒', t: 'Душнила', d: 'Три «3» подряд.' },
        'lover': { i: '🤝', t: 'Меценат', d: 'Пять «4» подряд.' },
        'stability': { i: '🗿', t: 'Стабильность', d: 'Десять троек за одну сессию.' },
        'combo_breaker': { i: '⚡', t: 'Комбо-Брейкер', d: 'Сразу после «2» влепили кому-то «5».' },
        'rollercoaster': { i: '🎢', t: 'Амер. Горки', d: 'Чередование оценок: 5, 2, 5, 2.' },
        'straight_flush': { i: '🃏', t: 'Стрит-Флеш', d: 'Поставили подряд 2, 3, 4 и 5.' },
        'stairway_down': { i: '📉', t: 'Спуск на Дно', d: 'Поставили подряд 5, 4, 3, 2.' },
        'generous': { i: '🤑', t: 'Джекпот', d: 'Поставили 50 пятерок за одну сессию!' },
        'ruthless': { i: '🌋', t: 'Извержение', d: 'Влепили 20 двоек за одну сессию.' },
        'rain_of_twos': { i: '🌧️', t: 'Дождь из Двоек', d: 'Поставили 15 двоек за сессию.' },
        'rain_of_fives': { i: '🌠', t: 'Звездопад', d: 'Поставили 30 пятерок за сессию.' },
        'yin_yang': { i: '☯️', t: 'Инь-Ян', d: 'Поставили ровно пять «5» и пять «2» за сессию.' },
        'slevin': { i: '🍀', t: 'Число Слевина', d: 'Выставили 77 оценок за сессию.' },
        'lucky_seven': { i: '🎰', t: 'Семерка', d: 'Поставили ровно 7 пятерок за сессию.' },
        'blackjack': { i: '🃏', t: 'Блэкджек', d: 'Поставили ровно 21 оценку за сессию.' },
        'perfectionist': { i: '✨', t: 'Перфекционист', d: 'Выставили оценку каждому в группе.' },

        'flawless': { i: '🛡️', t: 'Неуязвимые', d: 'Группа без единой буквы «Н» на экране.' },
        'plague': { i: '🦠', t: 'Эпидемия', d: 'Больше 10 пропусков (Н) на странице.' },
        'ghost_town': { i: '🏚️', t: 'Город-Призрак', d: 'На странице 30 или больше пропусков (Н).' },
        'hospital': { i: '🏥', t: 'Лазарет', d: 'На странице 20 или больше больничных (Б/У/П).' },

        'streak_5': { i: '🔥', t: 'В Огне', d: 'Заходили в МЭШ 5 дней подряд.' },
        'streak_10': { i: '☢️', t: 'МЭШ-зависимость', d: '10 дней подряд в журнале.' },
        'streak_30': { i: '📅', t: 'Месяц без Выходных', d: 'Заходили в МЭШ 30 дней подряд.' },
        'veteran': { i: '🎖️', t: 'Ветеран', d: 'Провели в МЭШ суммарно 30 разных дней.' },
        'hundred_days': { i: '🗓️', t: 'Сотня', d: 'Провели в МЭШ суммарно 100 разных дней.' },
        'half_year': { i: '⏳', t: 'Полгода Жизни', d: '180 дней в журнале. Вы живете здесь.' },

        'architect': { i: '🏗️', t: 'Архитектор', d: 'Использовали модуль перекраски.' },
        'picasso': { i: '🎨', t: 'Пикассо', d: 'Изменили множество элементов в Архитекторе.' },
        'hacker': { i: '💻', t: 'Хакер', d: 'Экстремально перестроили интерфейс Архитектором.' },
        'spy': { i: '🕵️‍♂️', t: 'Агент 007', d: 'Включили шпиона API.' },
        'turbo': { i: '⚡', t: 'Флэш', d: 'Включили ускорение анимаций.' },
        'ktp_master': { i: '📅', t: 'Повелитель Времени', d: 'Открыли страницу КТП.' },
        'absence_mode': { i: '👻', t: 'Охотник за Н-ками', d: 'Открыли режим отсутствия.' },
        'symbiote': { i: '🕷️', t: 'Симбиот', d: 'Выбрали Оценку с Весом 2.' },
        'weight_1': { i: '🪶', t: 'Легкотня', d: 'Выставили оценку с Весом 1.' },
        'all_5': { i: '⭐', t: 'Раздача Слонов', d: 'Использовали массовый режим "Всем 5".' },
        'all_2': { i: '🌩️', t: 'Гроза Курса', d: 'Использовали массовый режим "Всем 2".' },
        'col_picker': { i: '🗓️', t: 'Матрица Дат', d: 'Использовали выделение столбцов.' },
        
        'undo_master': { i: '⏪', t: 'Машина Времени', d: 'Удалили оценку Ластиком или Ctrl+Z.' },
        'undo_spam': { i: '♻️', t: 'Нерешительность', d: 'Отменили 5 оценок за одну сессию.' },
        'alt_eraser': { i: '🧹', t: 'Уборщик', d: 'Использовали скрытый Alt+Клик для удаления.' },
        'pdf_dossier': { i: '🖨️', t: 'Бюрократ', d: 'Сгенерировали PDF-досье на студента.' },
        'inspector': { i: '🔍', t: 'Инспектор', d: 'Скачали досье 5 раз за одну сессию.' },
        
        'fast_fingers': { i: '🖱️', t: 'Быстрые Пальцы', d: 'Поставили 5 оценок меньше чем за 3 сек.' },
        'speed_demon': { i: '🏎️', t: 'Спидраннер', d: 'Поставили 10 оценок быстрее 10 сек.' },
        'marathon': { i: '🏃', t: 'Марафонец', d: 'Провели на странице журнала больше 30 минут.' },
        'coffee': { i: '☕', t: 'Кофе-брейк', d: 'Отошли за чаем (неактивность 15 минут).' },
        'coffee_addict': { i: '☕☕', t: 'Кофеиновый Маньяк', d: 'Отошли от ПК 3 раза за сессию.' },
        'night_owl': { i: '🦉🦉', t: 'Сова 80лвл', d: 'Сделали 50 действий глубокой ночью.' },

        'ambassador': { i: '💎', t: 'Амбассадор', d: 'Собрали 10 достижений!' },
        'collector': { i: '🗃️', t: 'Коллекционер', d: 'Собрали 50 достижений.' },
        'hoarder': { i: '🏆', t: 'Барахольщик', d: 'Собрали 75 достижений.' },
        'true_legend': { i: '🌌', t: 'Истинная Легенда', d: 'Собрали ВСЕ 104 достижения! Вы прошли МЭШ.' }
    };

    const modal = document.getElementById('ach-modal');
    const infoPanel = document.getElementById('ach-info-panel');
    
    document.getElementById('btn-achievements').onclick = () => { modal.style.display = 'flex'; loadAchievements(); };
    document.getElementById('close-ach').onclick = () => { modal.style.display = 'none'; };
// КНОПКА ОТКРЫТИЯ ГАЙДА В НОВОЙ ВКЛАДКЕ
    document.getElementById('btn-guide').onclick = () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('guide.html') });
    };
    function loadAchievements() {
        chrome.storage.local.get(['MESH_ACHIEVEMENTS_PRO'], (res) => {
            let stats = res.MESH_ACHIEVEMENTS_PRO || { unlocked: {} };
            let grid = document.getElementById('ach-grid');
            grid.innerHTML = ''; 
            
            let unlockedCount = 0; let totalCount = Object.keys(BADGES).length;

            for (let key in BADGES) {
                let badge = BADGES[key];
                let isUnlocked = stats.unlocked[key] === true;
                if (isUnlocked) unlockedCount++;

                let item = document.createElement('div');
                item.className = 'ach-item' + (isUnlocked ? ' unlocked' : '');
                let displayDesc = isUnlocked ? badge.d : '?????????????????????';
                let displayTitle = isUnlocked ? badge.t : 'СЕКРЕТ';

                item.innerHTML = `<span class="ach-icon">${badge.i}</span><span class="ach-title">${displayTitle}</span>`;
                item.onmouseover = () => {
                    infoPanel.innerHTML = `
                        <div style="font-weight:bold; color:${isUnlocked ? '#01cdfe' : '#8b949e'}; font-size:14px; margin-bottom:6px; text-transform:uppercase; text-shadow: ${isUnlocked ? '0 0 5px #01cdfe' : 'none'};">
                            ${badge.i} ${displayTitle}
                        </div>
                        <div style="color:${isUnlocked ? '#fff' : '#666'}; font-size:11px; font-family:'Courier New', monospace; line-height: 1.4;">${displayDesc}</div>
                    `;
                };
                item.onmouseout = () => { infoPanel.innerHTML = `<span style="color: #8b949e; font-size: 11px; font-style: italic;">Наведите курсор на ачивку, чтобы узнать условия её получения</span>`; };
                grid.appendChild(item);
            }

            setTimeout(() => { document.getElementById('ach-progress-bar').style.width = (unlockedCount / totalCount * 100) + '%'; }, 100);
            document.getElementById('ach-stats-text').innerText = `Открыто: ${unlockedCount} / ${totalCount} (${Math.round(unlockedCount/totalCount*100)}%)`;
        });
    }
});