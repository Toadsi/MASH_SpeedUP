// ==========================================
// 📊 MESH Absences & Dossier (v5.0 - Ultra Minimal)
// ==========================================
(function() {
    console.log("📊 MESH Absences: Ультра-минималистичный режим (только пропуски и ср. балл)");

    let isEnabled = true;
    chrome.storage.sync.get(['calcAttendance'], (data) => {
        if (data && data.calcAttendance !== undefined) isEnabled = data.calcAttendance;
    });

    chrome.runtime.onMessage.addListener((req) => {
        if (req.action === "updateSettings" && req.settings.calcAttendance !== undefined) {
            isEnabled = req.settings.calcAttendance;
        }
    });

    const tooltip = document.createElement('div');
    tooltip.id = 'mesh-absence-tooltip';
    tooltip.style.cssText = `
        position: fixed; display: none; z-index: 9999999;
        background: rgba(30, 39, 46, 0.95); backdrop-filter: blur(10px);
        border: 1px solid #3498db; border-radius: 8px; padding: 12px;
        color: white; font-family: 'Segoe UI', sans-serif; box-shadow: 0 10px 25px rgba(0,0,0,0.5);
        min-width: 180px; transition: opacity 0.2s; pointer-events: auto;
    `;
    document.body.appendChild(tooltip);

    let hideTimeout;

    document.addEventListener('mouseover', (e) => {
        if (!isEnabled || !window.location.href.includes('journal')) return;

        let target = e.target;
        if (!target.closest) return;

        let nameCell = target.closest('td:first-child, [role="row"] > [role="gridcell"]:first-child, [data-test-component="StudentName"]');
        
        if (nameCell && nameCell.innerText.trim().length > 3) {
            
            // Защита от шапки
            if (nameCell.getAttribute('role') === 'columnheader' || nameCell.closest('thead') || nameCell.querySelector('.ant-select')) {
                return;
            }

            let row = nameCell.closest('tr, [role="row"]');
            if (!row) return;

            let rawTextLines = nameCell.innerText.split('\n');
            let validNameLine = rawTextLines.find(l => /[а-яА-Яa-zA-Z]{3,}/.test(l) && !/^\d+$/.test(l.trim()));
            if (!validNameLine) return;
            
            let studentName = validNameLine.replace(/^\d+\s+/, '').trim();

            if (studentName.length > 50 || studentName.includes('/') || studentName.includes('Журнал')) {
                return;
            }

            clearTimeout(hideTimeout);
            
            let stats = { nCount: 0, bCount: 0, average: '—' };
            let cells = row.querySelectorAll('td, [role="gridcell"]');
            
            cells.forEach(c => {
                let t = c.innerText.trim();
                if (/^[2-5][.,]\d{1,2}$/.test(t)) stats.average = t;
                
                // Считаем только буквы пропусков
                let marks = t.replace(/[^НнБбУуПп]/g, '').toUpperCase().split('');
                marks.forEach(m => {
                    if (m === 'Н') stats.nCount++;
                    else if (['Б','У','П'].includes(m)) stats.bCount++;
                });
            });

            tooltip.innerHTML = `
                <div style="font-weight:bold; color:#3498db; margin-bottom:10px; font-size:13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${studentName}">🎓 ${studentName}</div>
                
                <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:2px;"><span>Прогулы (Н):</span><b style="color:#e74c3c">${stats.nCount}</b></div>
                <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:4px;"><span>Болезнь (Б):</span><b style="color:#f1c40f">${stats.bCount}</b></div>
                <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:12px;"><span>Ср. балл:</span><b style="color:#fff">${stats.average}</b></div>
                
                <button id="mesh-pdf-btn" style="width:100%; background:#9b59b6; color:#fff; border:none; padding:8px; border-radius:4px; cursor:pointer; font-weight:bold; font-size:12px; box-shadow: 0 2px 5px rgba(155, 89, 182, 0.4);">📄 Скачать PDF-Справку</button>
            `;

            let rect = nameCell.getBoundingClientRect();
            tooltip.style.left = (rect.right + 10) + 'px';
            tooltip.style.top = (rect.top - 10) + 'px';
            tooltip.style.display = 'block';
            tooltip.style.opacity = '1';

            document.getElementById('mesh-pdf-btn').onclick = () => {
                generatePDF(studentName, stats);
            };
        }
    });

    document.addEventListener('mouseout', (e) => {
        if (e.target.closest('#mesh-absence-tooltip')) return;
        let nameCell = e.target.closest ? e.target.closest('td:first-child, [role="row"] > [role="gridcell"]:first-child, [data-test-component="StudentName"]') : null;
        if (nameCell) {
            hideTimeout = setTimeout(() => { tooltip.style.opacity = '0'; setTimeout(()=>tooltip.style.display='none', 200); }, 300);
        }
    });

    tooltip.addEventListener('mouseenter', () => clearTimeout(hideTimeout));
    tooltip.addEventListener('mouseleave', () => {
        hideTimeout = setTimeout(() => { tooltip.style.opacity = '0'; setTimeout(()=>tooltip.style.display='none', 200); }, 300);
    });

    function generatePDF(name, stats) {
        const d = new Date().toLocaleDateString('ru-RU');
        const html = `
        <!DOCTYPE html><html><head><meta charset="utf-8"><title>Справка_${name.replace(/\s+/g, '_')}</title>
        <style>
            body { font-family: 'Times New Roman', Times, serif; padding: 40px; color: #000; line-height: 1.6; }
            .header-info { text-align: right; margin-bottom: 50px; font-size: 14px;}
            .main-title { text-align: center; font-size: 20px; font-weight: bold; margin-bottom: 40px; text-transform: uppercase; letter-spacing: 1px;}
            .info-table { width: 100%; border-collapse: collapse; margin-bottom: 40px; font-size: 16px;}
            .info-table td { padding: 10px; border-bottom: 1px solid #ccc; vertical-align: top;}
            .label { width: 30%; color: #333; }
            .val-bold { font-weight: bold; }
            .stats-grid { display: flex; justify-content: space-around; align-items: center; border: 2px solid #000; padding: 30px; border-radius: 8px; margin-bottom: 50px;}
            .stat-box { text-align: center; width: 33%;}
            .stat-box h3 { margin: 0 0 10px 0; font-size: 14px; font-weight: normal; text-transform: uppercase; color: #555; }
            .stat-box .number { font-size: 40px; font-weight: bold; }
            .signatures { display: flex; justify-content: space-between; margin-top: 60px; font-size: 16px; }
            .sign-line { display: inline-block; width: 200px; border-bottom: 1px solid #000; margin-left: 10px;}
            
            /* ПРИНУДИТЕЛЬНАЯ КНИЖНАЯ ОРИЕНТАЦИЯ ДЛЯ ПЕЧАТИ */
            @media print { 
                @page { size: portrait; margin: 1.5cm; } 
                body { padding: 0; } 
            }
        </style></head><body>
            <div class="header-info">
                Дата формирования: <b>${d}</b><br>
                Подготовлено в модуле: <b>MESH Core</b>
            </div>
            <div class="main-title">Справка об успеваемости и посещаемости</div>
            
            <table class="info-table">
                <tr><td class="label">Обучающийся:</td><td class="val-bold">${name}</td></tr>
            </table>
            
            <div class="stats-grid">
                <div class="stat-box"><h3>Средний балл</h3><div class="number">${stats.average}</div></div>
                <div class="stat-box"><h3>Прогулы (Н)</h3><div class="number">${stats.nCount}</div></div>
                <div class="stat-box"><h3>Болезнь (Б/У/П)</h3><div class="number">${stats.bCount}</div></div>
            </div>
            
            <div class="signatures">
                <div>Преподаватель: <span class="sign-line"></span></div>
                <div>Ознакомлен(а): <span class="sign-line"></span></div>
            </div>
            <script>window.onload=()=>setTimeout(()=>window.print(), 500);</script>
        </body></html>`;
        
        let w = window.open('', '_blank');
        if(w) { w.document.write(html); w.document.close(); }
        else alert("⚠️ Ваш браузер заблокировал окно. Разрешите всплывающие окна для МЭШ.");
    }
})();