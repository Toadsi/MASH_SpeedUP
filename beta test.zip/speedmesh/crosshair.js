(function() {
    console.log("🎯 MESH Crosshair: Умный прицел v2 (Поверх имен, в границах таблицы)");

    let initIvl = setInterval(() => {
        if (document.body) {
            clearInterval(initIvl);
            initCrosshair();
        }
    }, 100);

    function initCrosshair() {
        // Горизонтальная линия
        const xLine = document.createElement('div');
        xLine.id = 'mesh-crosshair-x';
        // ВАЖНО: z-index 99, чтобы перекрывать липкие колонки с именами
        xLine.style.cssText = 'position:fixed; background:rgba(52, 152, 219, 0.15); pointer-events:none; z-index:99; display:none; transition: top 0.05s ease, height 0.05s ease; will-change: top, height, left, width;';
        
        // Вертикальная линия
        const yLine = document.createElement('div');
        yLine.id = 'mesh-crosshair-y';
        yLine.style.cssText = 'position:fixed; background:rgba(52, 152, 219, 0.15); pointer-events:none; z-index:99; display:none; transition: left 0.05s ease, width 0.05s ease; will-change: left, width, top, height;';

        document.body.appendChild(xLine);
        document.body.appendChild(yLine);

        let activeCell = null;
        let isEnabled = true;

        // Синхронизация с тумблером "Автооценки"
        chrome.storage.sync.get(['autoGrader'], (data) => {
            if (data && data.autoGrader === false) isEnabled = false;
        });
        
        chrome.runtime.onMessage.addListener((req) => {
            if (req.action === "updateSettings") {
                isEnabled = req.settings.autoGrader !== false;
                if (!isEnabled) { xLine.style.display = 'none'; yLine.style.display = 'none'; }
            }
        });

        document.addEventListener('mousemove', (e) => {
            if (!isEnabled || !window.location.href.includes('journal')) {
                xLine.style.display = 'none';
                yLine.style.display = 'none';
                return;
            }

            // Ищем ячейку под курсором
            const cell = e.target.closest('td, th, [role="cell"], [role="gridcell"], .ant-table-cell');
            
            // Не рисуем, если навели на самую верхнюю шапку с датами
            if (!cell || cell.closest('thead') || cell.closest('.ant-table-thead')) {
                xLine.style.display = 'none';
                yLine.style.display = 'none';
                activeCell = null;
                return;
            }

            if (activeCell === cell) return;
            activeCell = cell;

            const rect = cell.getBoundingClientRect();

            // 1. Ищем ГРАНИЦЫ САМОЙ ТАБЛИЦЫ, чтобы не лезть на меню и шапку сайта
            const tableWrapper = cell.closest('.ant-table-wrapper, .Dnevnik-grid, table') || document.querySelector('main') || document.querySelector('.ant-layout-content') || document.body;
            const wrapRect = tableWrapper.getBoundingClientRect();

            // 2. ГОРИЗОНТАЛЬНАЯ ЛИНИЯ: 
            // Начинается строго от левого края таблицы (покрывая имена) и заканчивается на правом крае.
            xLine.style.left = Math.max(wrapRect.left, 0) + 'px';
            xLine.style.width = wrapRect.width + 'px';
            xLine.style.top = rect.top + 'px';
            xLine.style.height = rect.height + 'px';
            xLine.style.display = 'block';

            // 3. ВЕРТИКАЛЬНАЯ ЛИНИЯ:
            // Ограничиваем высоту рамками таблицы, чтобы она не уходила вверх за пределы журнала.
            yLine.style.top = Math.max(wrapRect.top, 0) + 'px';
            const visibleHeight = Math.min(wrapRect.bottom, window.innerHeight) - Math.max(wrapRect.top, 0);
            yLine.style.height = visibleHeight + 'px';
            yLine.style.left = rect.left + 'px';
            yLine.style.width = rect.width + 'px';
            yLine.style.display = 'block';
        });

        // Прячем при уходе мыши со страницы
        document.addEventListener('mouseleave', () => {
            xLine.style.display = 'none';
            yLine.style.display = 'none';
            activeCell = null;
        });
    }
})();