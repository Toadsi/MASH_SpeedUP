console.log("🎯 MESH Assistant: Модуль Оценок (v6.1 - Final Refresh & Alt+Click Eraser)");

const SELECTORS = { tableRows: 'tr, [role="row"], .Dnevnik-grid-row' };

try {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('interceptor.js');
    s.onload = function() { this.remove(); };
    (document.head || document.documentElement).appendChild(s);
} catch (e) {}

let extSettings = { autoGrader: true, highlightGrades: true };
let isRobotActive = false;
let globalGradeMode = "AUTO";
let isColumnPickerActive = false;
let meshAbortProcess = false; 
const cellStylesCache = new WeakMap(); 
let undoHistoryStack = []; 

let initInterval = setInterval(() => {
    if (document.body) {
        clearInterval(initInterval);
        injectMainCSS();
        chrome.storage.sync.get(null, (data) => {
            if (data) {
                if (data.autoGrader !== undefined) extSettings.autoGrader = data.autoGrader;
                if (data.highlightGrades !== undefined) extSettings.highlightGrades = data.highlightGrades;
            }
        });
        setInterval(() => { 
            if (!isRobotActive) { runCoreLogic(); colorizeAverageGrades(); }
        }, 1000);
    }
}, 50);

chrome.runtime.onMessage.addListener((req) => {
    if (req.action === "updateSettings") {
        extSettings = { ...extSettings, ...req.settings };
        if (extSettings.autoGrader === false) removePhantomsAndPanel();
    }
});

// ГЛОБАЛЬНЫЙ СЛУШАТЕЛЬ: CTRL+Z для истории
document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (undoHistoryStack.length > 0 && !isRobotActive) {
            e.preventDefault();
            let lastAction = undoHistoryStack[undoHistoryStack.length - 1]; 
            executeUndoDelete(lastAction.id, lastAction.badge, lastAction.cell);
        }
    }
});

// ГЛОБАЛЬНЫЙ СЛУШАТЕЛЬ: Alt + Click для удаления ЛЮБЫХ оценок
document.addEventListener('click', (e) => {
    if (e.altKey && !isRobotActive) {
        let cell = e.target.closest('[data-test-component*="markCell"]');
        if (cell) {
            e.preventDefault(); e.stopPropagation();
            
            let attr = cell.getAttribute('data-test-component');
            let parts = attr.replace('markCell-', '').split('_');
            const studentId = parts[0];
            const lessonId = parts[1];
            
            let map = JSON.parse(window.sessionStorage.getItem('MESH_MARKS_MAP') || '{}');
            let markId = map[`${studentId}_${lessonId}`];
            
            if (markId) {
                let visualTarget = cell.querySelector('div, span, p') || cell;
                executeUndoDelete(markId, visualTarget, cell);
            } else {
                alert("🕵️‍♂️ ID этой оценки не найден в кэше браузера.\nПожалуйста, удалите её штатным способом МЭШ.");
            }
        }
    }
}, true);

// ФУНКЦИЯ УДАЛЕНИЯ ОЦЕНКИ (API DELETE)
async function executeUndoDelete(markId, visualElement, cell) {
    if(!confirm('🗑️ Точно удалить эту оценку?')) return;
    
    let originalHTML = visualElement.innerHTML;
    let originalBg = visualElement.style.background;
    
    visualElement.innerHTML = "⏳";
    visualElement.style.background = "#f39c12";
    visualElement.style.color = "white";

    const tk = document.cookie.match(/(?:^|; )aupd_token=([^;]*)/); const pr = document.cookie.match(/(?:^|; )profile_id=([^;]*)/);
    const aupd_token = tk ? decodeURIComponent(tk[1]) : null; const profile_id = pr ? decodeURIComponent(pr[1]) : null;

    if (!aupd_token || !profile_id) return alert("Ошибка авторизации. Обновите страницу.");

    try {
        const res = await fetch(`https://school.mos.ru/api/profeducation/core/teacher/v1/marks/${markId}`, {
            method: "DELETE",
            headers: { "Accept": "application/json", "Authorization": `Bearer ${aupd_token}`, "Profile-Id": profile_id, "x-mes-subsystem": "journalw" }
        });
        
        if (res.ok) {
            visualElement.innerHTML = "🗑️";
            visualElement.style.background = "#7f8c8d";
            undoHistoryStack = undoHistoryStack.filter(item => item.id !== markId);
            setTimeout(() => {
                visualElement.remove(); // Убираем элемент, чтобы сработал runCoreLogic и поставил '+'
                runCoreLogic(); 
            }, 1000);
        } else {
            visualElement.innerHTML = "❌";
            visualElement.style.background = "#e74c3c";
            setTimeout(() => { visualElement.innerHTML = originalHTML; visualElement.style.background = originalBg; }, 2000);
        }
    } catch(e) {
        visualElement.innerHTML = "❌";
        setTimeout(() => { visualElement.innerHTML = originalHTML; visualElement.style.background = originalBg; }, 2000);
    }
}

function removePhantomsAndPanel() {
    document.querySelectorAll('.mesh-phantom-grade').forEach(el => el.remove());
    document.querySelectorAll('.mesh-col-selectable').forEach(el => el.classList.remove('mesh-col-selectable', 'mesh-col-selected'));
    document.querySelectorAll('[data-robot-target-grade]').forEach(el => el.removeAttribute('data-robot-target-grade'));
    let p = document.getElementById('mesh-robot-panel');
    if (p) p.style.display = 'none';
    isColumnPickerActive = false;
}

function colorizeAverageGrades() {
    if (!extSettings.highlightGrades) return;
    document.querySelectorAll('td, [role="cell"], [role="gridcell"]').forEach(cell => {
        const text = cell.innerText.trim();
        if (/^[2-5][.,]\d{1,2}$/.test(text) && !cell.dataset.meshColored) {
            let fAvg = parseFloat(text.replace(',', '.'));
            let color = '#c0392b'; 
            if (fAvg >= 4.5) color = '#27ae60'; else if (fAvg >= 3.5) color = '#3498db'; else if (fAvg >= 2.5) color = '#f39c12'; 
            let target = cell.querySelector('div, span') || cell;
            target.style.setProperty('color', '#fff', 'important'); target.style.setProperty('background-color', color, 'important'); target.style.setProperty('border-radius', '4px', 'important'); target.style.setProperty('font-weight', 'bold', 'important'); target.style.setProperty('padding', '2px 6px', 'important'); target.style.setProperty('display', 'inline-block', 'important'); cell.dataset.meshColored = "true";
        }
    });
}

function injectMainCSS() {
    if (document.getElementById('mesh-injected-styles')) return;
    const style = document.createElement('style'); style.id = 'mesh-injected-styles';
    style.innerHTML = `
        .mesh-phantom-grade { background-color: #3498db !important; color: white !important; border-radius: 4px !important; padding: 3px 7px !important; font-weight: bold !important; font-size: 11px !important; box-shadow: 0 0 10px rgba(52, 152, 219, 0.6) !important; position: absolute !important; top: 50% !important; left: 50% !important; transform: translate(-50%, -50%) !important; z-index: 10 !important; cursor: pointer; user-select: none; }
        .mesh-phantom-grade:hover { transform: translate(-50%, -50%) scale(1.15) !important; }
        .mesh-phantom-dormant { background-color: transparent !important; color: transparent !important; box-shadow: none !important; border: 1px dashed rgba(52, 152, 219, 0.4) !important; opacity: 0; transition: 0.2s; }
        td:hover .mesh-phantom-dormant { opacity: 1; color: #3498db !important; background-color: rgba(52, 152, 219, 0.1) !important; }
        th.mesh-col-selectable { cursor: cell !important; box-shadow: inset 0 0 0 3px #3498db !important; background-color: rgba(52, 152, 219, 0.1) !important; transition: 0.2s; position: relative !important; }
        th.mesh-col-selectable:hover { background-color: rgba(52, 152, 219, 0.25) !important; }
        th.mesh-col-selected { box-shadow: inset 0 0 0 3px #2ecc71 !important; background-color: rgba(46, 204, 113, 0.25) !important; }
        #mesh-robot-panel { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%); background: #1e272e; color: white; padding: 15px 25px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.6); z-index: 9999999; display: flex; align-items: center; gap: 20px; font-family: "Segoe UI", sans-serif; border: 1px solid #34495e; transition: 0.3s; }
        .api-success-badge { background:#27ae60; color:#fff; border-radius:4px; padding:3px 6px; font-weight:bold; font-size:11px; display:inline-block; transition:0.2s; }
        .api-success-badge:hover { filter: brightness(1.2); transform: scale(1.05); }
        .api-error-badge { background:#e74c3c; color:#fff; border-radius:4px; padding:3px 6px; font-weight:bold; font-size:11px; display:inline-block; cursor:help;}
    `;
    document.head.appendChild(style);
}

function findDateColumnHeaders() {
    const results = [];
    document.querySelectorAll('th, [role="columnheader"]').forEach(cell => {
        const rect = cell.getBoundingClientRect();
        if (rect.top > 250 || rect.width === 0) return;
        if (/\d{1,2}/.test(cell.textContent) && !cell.textContent.includes('Ср')) results.push(cell);
    });
    return results;
}

function startColumnPicker() {
    let headers = findDateColumnHeaders();
    if (headers.length === 0) return alert("Не удалось найти даты.");
    isColumnPickerActive = true;
    headers.forEach(h => { h.classList.add('mesh-col-selectable'); h.onclick = (e) => { e.preventDefault(); e.stopPropagation(); h.classList.toggle('mesh-col-selected'); }; });
    runCoreLogic(); 
}

function cancelColumnPicker() {
    document.querySelectorAll('.mesh-col-selectable').forEach(h => { h.classList.remove('mesh-col-selectable', 'mesh-col-selected'); h.onclick = null; });
    isColumnPickerActive = false; runCoreLogic();
}

function applyColumnPicker() {
    let selectedHeaders = Array.from(document.querySelectorAll('.mesh-col-selected'));
    let activeColumnsX = selectedHeaders.map(th => { let r = th.getBoundingClientRect(); return { x: r.left + r.width / 2, width: r.width }; });
    cancelColumnPicker();

    if (activeColumnsX.length > 0) {
        document.querySelectorAll(SELECTORS.tableRows).forEach(row => {
            let fAvg = getSuggestedFromRow(row);
            let suggested = Math.round(fAvg); if (suggested < 2) suggested = 2; if (suggested > 5) suggested = 5;
            if (fAvg >= 2) {
                row.querySelectorAll('td, [role="gridcell"]').forEach(c => {
                    let r = c.getBoundingClientRect();
                    if (r.width > 0) {
                        let cx = r.left + r.width / 2;
                        let match = activeColumnsX.some(col => Math.abs(cx - col.x) < col.width * 0.45);
                        if (match && isCellUnlocked(c)) {
                            let ph = c.querySelector('.mesh-phantom-grade');
                            if (ph) { ph.dataset.active = 'true'; ph.dataset.grade = globalGradeMode === "AUTO" ? suggested.toString() : globalGradeMode; updatePhantomVisuals(ph, c); }
                        }
                    }
                });
            }
        });
    }
    runCoreLogic();
}

function isCellUnlocked(el) {
    if (el.className && typeof el.className === 'string' && el.className.match(/(disabled|locked|readonly)/i)) return false;
    if (!cellStylesCache.has(el)) {
        const bg = window.getComputedStyle(el).backgroundColor;
        const rgbMatch = bg.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);
        let locked = false;
        if (rgbMatch) {
            const r = parseInt(rgbMatch[1]), g = parseInt(rgbMatch[2]), b = parseInt(rgbMatch[3]);
            if (r >= 230 && r <= 250 && Math.abs(r-g) <= 10 && Math.abs(g-b) <= 10) locked = true;
            if (r === 242 && g === 242 && b === 242) locked = true;
        }
        cellStylesCache.set(el, locked);
    }
    return !cellStylesCache.get(el); 
}

function getSuggestedFromRow(row) {
    let fAvg = 0;
    row.querySelectorAll('span, div, p, td').forEach(cell => { const text = cell.textContent.trim(); if (/^[2-5][.,]\d{1,2}$/.test(text)) fAvg = parseFloat(text.replace(',', '.')); });
    return fAvg;
}

function isAbsenceModeActive() {
    const activeToggles = document.querySelectorAll('.ant-radio-button-wrapper-checked, .ant-segmented-item-selected');
    for (let toggle of activeToggles) {
        const text = toggle.innerText ? toggle.innerText.toLowerCase() : '';
        if (text.includes('отсутстви')) return true;
        if (text.includes('расширенный')) return false;
    }
    return false;
}

function runCoreLogic() {
    if (!extSettings.autoGrader || !window.location.href.includes('journal') || isAbsenceModeActive()) { removePhantomsAndPanel(); return; }

    const rows = document.querySelectorAll(SELECTORS.tableRows);
    if (rows.length === 0) return;

    let activePhantomsCount = 0;

    rows.forEach(row => {
        if (row.offsetHeight === 0) return; 
        let fAvg = getSuggestedFromRow(row);
        let suggested = Math.round(fAvg); if (suggested < 2) suggested = 2; if (suggested > 5) suggested = 5;

        let cells = Array.from(row.querySelectorAll('td, [role="gridcell"]'));
        
        cells.forEach(c => {
            let hasRealContent = false;
            for (let node of c.childNodes) {
                if (node.nodeType === 3 && node.nodeValue.trim() !== '') { hasRealContent = true; break; }
                if (node.nodeType === 1 && !node.classList.contains('mesh-phantom-grade') && !node.classList.contains('api-success-badge') && node.textContent.trim() !== '') { hasRealContent = true; break; }
            }

            if (hasRealContent) {
                let existing = c.querySelector('.mesh-phantom-grade');
                if (existing) existing.remove(); c.removeAttribute('data-robot-target-grade'); return;
            }

            if (!isCellUnlocked(c)) return;

            let ph = c.querySelector('.mesh-phantom-grade');
            if (!ph) {
                ph = document.createElement('div'); ph.className = 'mesh-phantom-grade mesh-phantom-dormant'; ph.textContent = '+'; ph.dataset.active = 'false'; 
                if (window.getComputedStyle(c).position === 'static') c.style.position = 'relative';

                ph.onmousedown = (e) => {
                    e.preventDefault(); e.stopPropagation(); 
                    if (e.button === 0) { if (ph.dataset.active === 'false') { ph.dataset.active = 'true'; ph.dataset.grade = globalGradeMode === "AUTO" ? suggested.toString() : globalGradeMode; } else { let g = parseInt(ph.dataset.grade); g--; if (g < 2) g = 5; ph.dataset.grade = g.toString(); } } else if (e.button === 2) { ph.dataset.active = 'false'; }
                    updatePhantomVisuals(ph, c); runCoreLogic(); 
                };
                ph.oncontextmenu = (e) => e.preventDefault(); c.appendChild(ph);
            }
            if (ph.dataset.active === 'true') activePhantomsCount++;
        });
    });

    drawRobotPanel(activePhantomsCount);
}

function updatePhantomVisuals(ph, cell) {
    let isActive = ph.dataset.active === 'true';
    ph.className = 'mesh-phantom-grade ' + (isActive ? '' : 'mesh-phantom-dormant'); ph.textContent = isActive ? ph.dataset.grade : '+';
    if (isActive) cell.dataset.robotTargetGrade = ph.dataset.grade; else cell.removeAttribute('data-robot-target-grade');
}

function updateGlobalGrades() {
    document.querySelectorAll('.mesh-phantom-grade').forEach(ph => {
        if (ph.dataset.active === 'true') {
            if (globalGradeMode !== "AUTO") ph.dataset.grade = globalGradeMode;
            else { let row = ph.closest('tr, [role="row"]'); let fAvg = getSuggestedFromRow(row); let suggested = Math.round(fAvg); if (suggested < 2) suggested = 2; if (suggested > 5) suggested = 5; ph.dataset.grade = suggested.toString(); }
            updatePhantomVisuals(ph, ph.parentElement);
        }
    });
}

function drawRobotPanel(count) {
    let p = document.getElementById('mesh-robot-panel');
    if (!p) { p = document.createElement('div'); p.id = 'mesh-robot-panel'; document.body.appendChild(p); }
    p.style.display = 'flex';

    if (isColumnPickerActive) {
        p.innerHTML = `
            <div style="font-size:15px; font-weight:bold; color:#f1c40f;">🎯 Кликайте по датам (заголовкам) в таблице</div>
            <div style="display:flex; gap:10px; margin-left:15px;">
                <button id="mesh-cp-apply" style="background:#27ae60; color:white; border:none; padding:8px 15px; border-radius:6px; cursor:pointer; font-weight:bold;">✅ Применить авто-оценки</button>
                <button id="mesh-cp-cancel" style="background:#e74c3c; color:white; border:none; padding:8px 15px; border-radius:6px; cursor:pointer; font-weight:bold;">❌ Отмена</button>
            </div>
        `;
        document.getElementById('mesh-cp-apply').onclick = applyColumnPicker; document.getElementById('mesh-cp-cancel').onclick = cancelColumnPicker; return;
    }

    if (count === 0) {
        p.innerHTML = `
            <div style="font-size:13px; display:flex; flex-direction:column; gap:4px; padding-right:15px; border-right: 1px solid rgba(255,255,255,0.1);">
                <div style="color:#bdc3c7;">Выберите пустые ячейки (нажмите +)</div>
            </div>
            <button id="mesh-cp-start" style="background:#34495e; color:white; border:none; padding:8px 15px; border-radius:6px; cursor:pointer; font-weight:bold; margin-left:10px;">📅 Выбрать столбцы</button>
        `;
        document.getElementById('mesh-cp-start').onclick = startColumnPicker;
    } else {
        p.innerHTML = `
            <div style="font-size:13px; display:flex; flex-direction:column; gap:4px; padding-right:15px; border-right: 1px solid rgba(255,255,255,0.1);">
                <div>К отправке: <b id="mesh-robot-count" style="color:#3498db; font-size:16px;">${count}</b></div>
            </div>
            <div style="display:flex; gap:10px; align-items:center; margin-left:10px;">
                <button id="mesh-cp-start" title="Добавить столбцы" style="background:#34495e; color:white; border:none; border-radius:6px; padding:8px 10px; cursor:pointer;">➕ Столбцы</button>
                <select id="mesh-global-grade" title="Применить ко всем выделенным" style="background:#2c2c2e; color:white; border:1px solid #3498db; border-radius:8px; padding:8px; outline:none; cursor:pointer; font-weight:bold;">
                    <option value="AUTO" ${globalGradeMode==="AUTO"?"selected":""}>🤖 Средний балл</option> <option value="5" ${globalGradeMode==="5"?"selected":""}>⭐ Всем 5</option> <option value="4" ${globalGradeMode==="4"?"selected":""}>🟢 Всем 4</option> <option value="3" ${globalGradeMode==="3"?"selected":""}>🟡 Всем 3</option> <option value="2" ${globalGradeMode==="2"?"selected":""}>🔴 Всем 2</option>
                </select>
                <select id="mesh-global-weight" title="Вес оценки" style="background:#2c2c2e; color:white; border:1px solid #9b59b6; border-radius:8px; padding:8px; outline:none; cursor:pointer; font-weight:bold;">
                    <option value="2" selected>⚖️ Вес 2 (Практ. работа)</option>
                    <option value="1">⚖️ Вес 1</option>
                </select>
                <button id="mesh-robot-btn" style="background:#3498db; color:white; border:none; border-radius:6px; padding:10px 15px; cursor:pointer; font-weight:bold;">Отправить в МЭШ</button>
                <button id="mesh-reset-btn" title="Сбросить выделение" style="background:#e74c3c; color:white; border:none; border-radius:6px; padding:8px 10px; cursor:pointer;">🗑️</button>
            </div>
        `;
        document.getElementById('mesh-cp-start').onclick = startColumnPicker;
        document.getElementById('mesh-reset-btn').onclick = () => { document.querySelectorAll('.mesh-phantom-grade').forEach(ph => { ph.dataset.active = 'false'; updatePhantomVisuals(ph, ph.parentElement); }); runCoreLogic(); };
        document.getElementById('mesh-global-grade').onchange = (e) => { globalGradeMode = e.target.value; updateGlobalGrades(); };
        document.getElementById('mesh-robot-btn').onclick = startSmartMatrixAPI;
    }
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function startSmartMatrixAPI() {
    let cells = Array.from(document.querySelectorAll('[data-robot-target-grade]'));
    if (cells.length === 0) return alert("Нет выбранных оценок!");

    const wDropdown = document.getElementById('mesh-global-weight');
    const selectedWeight = wDropdown ? parseInt(wDropdown.value, 10) : 2;

    if (!confirm(`🚀 Отправить оценки в МЭШ?\n\nВыбранный вес: ${selectedWeight}\n\nПродолжить?`)) return;

    isRobotActive = true; 
    meshAbortProcess = false; 
    
    const p = document.getElementById('mesh-robot-panel');
    if(p) { 
        p.innerHTML = `
            <div style="font-size:15px; text-align:center; width:100%; display:flex; align-items:center; justify-content:center; gap:15px;">
                <span>Отправка... <b id="mesh-robot-count" style="color:#2ecc71;">0 / ${cells.length}</b></span>
                <button id="mesh-robot-btn-stop" style="background:#e74c3c; color:white; border:none; border-radius:8px; padding:6px 15px; cursor:pointer; font-weight:bold; transition:0.2s;">Остановить</button>
            </div>`;
        document.getElementById('mesh-robot-btn-stop').addEventListener('click', function() {
            meshAbortProcess = true; this.innerText = "🛑 Остановка..."; this.style.background = "#c0392b"; this.style.pointerEvents = "none";
        });
    }

    let ok = 0; let err = 0; let firstFatalErrorLog = null; let winningGsId = null; 
    const tk = document.cookie.match(/(?:^|; )aupd_token=([^;]*)/); const pr = document.cookie.match(/(?:^|; )profile_id=([^;]*)/);
    const aupd_token = tk ? decodeURIComponent(tk[1]) : null; const profile_id = pr ? decodeURIComponent(pr[1]) : null;

    if (!aupd_token || !profile_id) { alert("❌ Ошибка авторизации. Обновите страницу (F5)."); isRobotActive = false; return; }

    let stolenWeight2CfId = null; let stolenWeight1CfId = null; let allPageCfIds = new Set();
    document.querySelectorAll('[data-test-component*="markCell"]').forEach(cell => {
        let attr = cell.getAttribute('data-test-component');
        let match = attr.match(/markCell[-_]\d+_\d+_(\d+)/);
        if (match) {
            let cfId = parseInt(match[1], 10);
            allPageCfIds.add(cfId);
            let text = cell.innerText.replace(/\s+/g, '');
            if (/[2-5НнБб]2$/.test(text) || cell.querySelector('sub, [class*="weight"]')?.innerText.includes('2')) stolenWeight2CfId = cfId;
            else stolenWeight1CfId = cfId;
        }
    });

    let localDb = { grade_system_ids: [], control_forms: [] };
    try { const stored = window.sessionStorage.getItem('MESH_GLOBAL_DB'); if (stored) localDb = JSON.parse(stored); } catch(e) {}

    for (let i = 0; i < cells.length; i++) {
        if (meshAbortProcess) break;

        const cell = cells[i]; const gradeStr = cell.dataset.robotTargetGrade;
        if(p) { let counter = document.getElementById('mesh-robot-count'); if (counter) counter.innerText = `${i+1} / ${cells.length}`; }
        
        cell.scrollIntoView({ behavior: "smooth", block: "center" });
        const ph = cell.querySelector('.mesh-phantom-grade'); if (ph) ph.style.display = 'none';
        
        let attrNode = cell.hasAttribute('data-test-component') ? cell : cell.querySelector('[data-test-component*="markCell"]');
        let attr = attrNode ? attrNode.getAttribute('data-test-component') : null;

        if (attr) {
            let parts = attr.replace('markCell-', '').split('_');
            const studentId = parseInt(parts[0], 10); const lessonId = parseInt(parts[1], 10);
            let domCfId = parts[2] !== "null" && parts[2] !== "undefined" ? parseInt(parts[2], 10) : null;

            let cfs = []; 
            if (domCfId) cfs.push(domCfId); 
            if (selectedWeight === 2 && stolenWeight2CfId && !cfs.includes(stolenWeight2CfId)) cfs.push(stolenWeight2CfId);
            if (selectedWeight === 1 && stolenWeight1CfId && !cfs.includes(stolenWeight1CfId)) cfs.push(stolenWeight1CfId);
            Array.from(allPageCfIds).forEach(id => { if (!cfs.includes(id)) cfs.push(id); });
            if (localDb.control_forms) { [...localDb.control_forms].reverse().forEach(cf => { if (!cfs.includes(cf)) cfs.push(cf); }); }
            if (selectedWeight === 1) cfs.push(null); 

            let gsIds = [...new Set([...localDb.grade_system_ids, 50365, 35133, 40166])]; 
            if (winningGsId !== null) gsIds = [winningGsId, ...gsIds.filter(id => id !== winningGsId)];

            let combosToTry = [];
            for (let cf of cfs) { for (let gs of gsIds) combosToTry.push({ w: selectedWeight, gs: gs, c: cf }); } 

            let success = false; let lastErrTxt = ""; let returnedMarkId = null;

            for (let combo of combosToTry) {
                if (meshAbortProcess) break; 
                try {
                    const payload = { "comment": "", "is_exam": false, "is_criterion": false, "is_point": false, "point_date": "", "schedule_lesson_id": lessonId, "student_profile_id": studentId, "teacher_id": parseInt(profile_id, 10), "control_form_id": combo.c, "weight": combo.w, "theme_frame_integration_id": null, "course_lesson_topic_id": null, "grade_origins": [{"grade_origin": gradeStr, "grade_system_id": combo.gs}], "grade_system_type": false };
                    const res = await fetch("https://school.mos.ru/api/profeducation/core/teacher/v1/marks", { method: "POST", headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": `Bearer ${aupd_token}`, "Profile-Id": profile_id, "x-mes-subsystem": "journalw" }, body: JSON.stringify(payload) });
                    if (res.ok) { 
                        success = true; winningGsId = combo.gs; 
                        try { const resData = await res.json(); returnedMarkId = resData.id || (Array.isArray(resData) && resData[0] ? resData[0].id : null); } catch(e) {}
                        break; 
                    } else { 
                        lastErrTxt = await res.text(); if (res.status === 401 || res.status === 500) break; 
                    }
                } catch (e) { lastErrTxt = e.message; break; }
            }

            let targetDiv = cell.querySelector('div') || cell; targetDiv.innerHTML = '';

            if (success) { 
                ok++; 
                let badge = document.createElement('div'); badge.className = 'api-success-badge'; badge.innerHTML = `✅ ${gradeStr}`;
                if (returnedMarkId) {
                    badge.title = "Кликните, чтобы удалить (Отмена)"; badge.style.cursor = "pointer";
                    badge.onclick = (e) => { e.preventDefault(); e.stopPropagation(); executeUndoDelete(returnedMarkId, badge, cell); };
                    undoHistoryStack.push({ id: returnedMarkId, badge: badge, cell: cell });
                }
                targetDiv.appendChild(badge);
            } 
            else { err++; targetDiv.innerHTML = `<div class="api-error-badge" title='${lastErrTxt}'>❌ Ошибка</div>`; if (err === 1) firstFatalErrorLog = { server_response: lastErrTxt }; }
        } else { err++; (cell.querySelector('div') || cell).innerHTML = `<div class="api-error-badge">❌ Сбой</div>`; }
        cell.removeAttribute('data-robot-target-grade'); if (ph) ph.remove(); await sleep(200);
    }
    
    isRobotActive = false;

    if (err > 0 && firstFatalErrorLog && ok === 0) {
        let logText = JSON.stringify(firstFatalErrorLog, null, 2); console.error("🔥 Ошибка сервера:\n", logText); prompt(`Сервер отклонил оценки. Лог ошибки:\n\n`, logText);
    } else if (p) {
        // ИДЕАЛЬНАЯ КНОПКА СОХРАНЕНИЯ / ОБНОВЛЕНИЯ
        p.innerHTML = `
            <div style="font-size:16px; font-weight:bold; color:#2ecc71; margin-right: 10px;">✅ Выставлено: ${ok} шт.</div>
            <button id="mesh-final-refresh" style="background:#2ecc71; color:white; border:none; border-radius:8px; padding:10px 20px; cursor:pointer; font-weight:bold; font-size:14px; box-shadow: 0 4px 15px rgba(46, 204, 113, 0.4); transition: 0.2s;">🔄 Обновить, чтобы сохранить</button>
        `;
        document.getElementById('mesh-final-refresh').onclick = () => window.location.reload();
        document.getElementById('mesh-final-refresh').onmouseover = function() { this.style.transform = 'scale(1.05)'; };
        document.getElementById('mesh-final-refresh').onmouseout = function() { this.style.transform = 'scale(1)'; };
    }
}