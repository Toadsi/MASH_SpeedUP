// ==========================================
// 🏆 MESH Achievements (Vaporwave Edition - 105 Badges)
// ==========================================
(function() {
    console.log("🌴 MESH Achievements: Движок (105 Ачивок) активирован!");

    let stats = { totalGrades: 0, totalDays: 0, lastDate: null, streak: 0, unlocked: {} };
    try {
        const saved = localStorage.getItem('MESH_ACHIEVEMENTS_PRO');
        if (saved) { stats = JSON.parse(saved); if (!stats.streak) stats.streak = 0; }
        if (!stats.unlocked) stats.unlocked = {};
    } catch(e) {}

    function saveStats() {
        localStorage.setItem('MESH_ACHIEVEMENTS_PRO', JSON.stringify(stats));
        chrome.storage.local.set({ 'MESH_ACHIEVEMENTS_PRO': stats });
    }
    chrome.storage.local.set({ 'MESH_ACHIEVEMENTS_PRO': stats });

    const BADGES = {
        'first_blood': { i: '🩸', t: 'Первая Кровь', d: 'Выставили первую авто-оценку.' },
        'novice': { i: '🌱', t: 'Новичок', d: 'Поставили 10 авто-оценок за всё время.' },
        'pro': { i: '🦾', t: 'Кибер-Препод', d: 'Поставили 50 авто-оценок. Вы втягиваетесь!' },
        'terminator': { i: '🤖', t: 'Терминатор', d: '100 оценок! Машина по выставлению баллов.' },
        'god': { i: '👑', t: 'Бог Журнала', d: '500 авто-оценок. Сервер МЭШ молится на вас.' },
        'cyborg': { i: '🦿', t: 'Киборг', d: 'Поставили 1000 авто-оценок. Вы забыли, как писать ручкой.' },
        'matrix': { i: '🕶️', t: 'Архитектор Матрицы', d: '5000 авто-оценок. Вы и есть МЭШ.' },
        'over_9000': { i: '💥', t: 'OVER 9000!', d: 'Более 9000 оценок. Ваш уровень запредельный!' },
        'three_axes': { i: '🎰', t: 'Три Топора', d: 'Выставили ровно 777 оценок за всё время.' },
        'devil': { i: '😈', t: 'Адский Труд', d: '666 авто-оценок за всё время.' },
        'owl': { i: '🦉', t: 'Ночной Дозор', d: 'Открыли МЭШ после полуночи (00:00 - 04:00).' },
        'vampire': { i: '🦇', t: 'Вампир', d: 'Глубокая ночь. Зашли с 02:00 до 03:00.' },
        'nightmare': { i: '🧛', t: 'Дракула', d: 'Зашли в МЭШ ровно в полночь (00:00).' },
        'sunrise': { i: '🌤️', t: 'Первые Лучи', d: 'Работаете на рассвете (с 05:00 до 06:00).' },
        'early_bird': { i: '🌅', t: 'Ранняя Пташка', d: 'Уже в журнале до 07:00 утра.' },
        'lunch_break': { i: '🍔', t: 'Без Обеда', d: 'Выставляете оценки с 13:00 до 14:00.' },
        'tea_time': { i: '🫖', t: 'Время Чая', d: 'Работаете ровно в 17:00.' },
        'overtime': { i: '🌃', t: 'Сверхурочные', d: 'Сидите в журнале после 20:00.' },
        'friday_party': { i: '🪩', t: 'Пятничный Вайб', d: 'Работаете в пятницу после 18:00.' },
        'weekend_warrior': { i: '⚔️', t: 'Трудоголик', d: 'Зашли в МЭШ в выходные.' },
        'monday': { i: '☠️', t: 'Тяжелый Понедельник', d: 'Зашли в МЭШ в понедельник до 10:00.' },
        'santa': { i: '🎅', t: 'Тайный Санта', d: 'Закрываете долги в декабре.' },
        'new_year': { i: '🥂', t: 'С Наступающим', d: 'Сидите в журнале 31 декабря.' },
        'grinch': { i: '🎄', t: 'Гринч', d: 'Работа в новогодние праздники (1-8 января).' },
        'student_day': { i: '🎓', t: 'Татьянин День', d: 'Работа в День студента (25 января).' },
        'valentines': { i: '💖', t: 'Любовь к Работе', d: 'Зашли в МЭШ 14 февраля.' },
        'defender': { i: '🪖', t: 'Защитник Журнала', d: 'Работаете 23 февраля.' },
        'womens_day': { i: '💐', t: 'Весенний Праздник', d: 'Работаете 8 марта.' },
        'pi_day': { i: '🥧', t: 'День Пи', d: 'Зашли в МЭШ 14 марта (3.14).' },
        'spring': { i: '🌸', t: 'Весеннее Обострение', d: 'Март-Апрель. Скоро сессия!' },
        'fool': { i: '🤡', t: 'День Дурака', d: 'Работа 1 апреля. Это не шутка?' },
        'cosmonaut': { i: '🚀', t: 'Поехали!', d: 'День космонавтики (12 апреля).' },
        'labor_day': { i: '🕊️', t: 'Мир, Труд, Май', d: 'Зашли в МЭШ 1 мая.' },
        'star_wars': { i: '☄️', t: 'Джедай', d: 'Зашли в МЭШ 4 мая (May the 4th).' },
        'victory': { i: '🎆', t: 'День Победы', d: 'Зашли в МЭШ 9 мая.' },
        'may_bugs': { i: '🐞', t: 'Майский Жук', d: 'Зашли в систему на майских праздниках.' },
        'summer': { i: '🏖️', t: 'Где мой отпуск?', d: 'Зашли в журнал летом.' },
        'knowledge': { i: '🔔', t: 'Снова в Школу', d: 'Работаете 1 сентября.' },
        'autumn': { i: '🍂', t: 'Снова в Бой', d: 'Сентябрь горит.' },
        'teachers_day': { i: '🧑‍🏫', t: 'Проф. Праздник', d: 'Зашли в МЭШ 5 октября (День Учителя).' },
        'halloween': { i: '🎃', t: 'Сладость/Гадость', d: 'Зашли в МЭШ 31 октября.' },
        'leap_year': { i: '🐸', t: 'Редкий Гость', d: '29 февраля. Бывает раз в 4 года.' },
        'lucky_13': { i: '🐈‍⬛', t: 'Пятница 13-е', d: 'Работаете в пятницу 13-го числа.' },
        'sniper': { i: '🎯', t: 'Снайпер', d: '15 успешных оценок за одну сессию.' },
        'machine_gun': { i: '🔫', t: 'Пулеметчик', d: '30 оценок за сессию.' },
        'centurion': { i: '💯', t: 'Центурион', d: '100 оценок за ОДНУ сессию. Монстр.' },
        'half_k': { i: '🪙', t: 'Полтысячи', d: '500 оценок за одну сессию. Рекорд!' },
        'good_cop': { i: '😇', t: 'Добрый Коп', d: 'Поставили пять «5» подряд!' },
        'executioner': { i: '🪓', t: 'Палач', d: 'Три «2» подряд.' },
        'hater': { i: '😒', t: 'Душнила', d: 'Три «3» подряд.' },
        'lover': { i: '🤝', t: 'Меценат', d: 'Пять «4» подряд.' },
        'stability': { i: '🗿', t: 'Стабильность', d: 'Десять троек за одну сессию.' },
        'combo_breaker': { i: '⚡', t: 'Комбо-Брейкер', d: 'Сразу после «2» влепили кому-то «5».' },
        'rollercoaster': { i: '🎢', t: 'Амер. Горки', d: 'Чередование оценок: 5, 2, 5, 2.' },
        'straight_flush': { i: '🃏', t: 'Стрит-Флеш', d: 'Поставили подряд 2, 3, 4 и 5.' },
        'stairway_down': { i: '📉', t: 'Спуск на Дно', d: 'Поставили подряд 5, 4, 3, 2.' },
        'generous': { i: '🤑', t: 'Джекпот', d: 'Поставили 50 пятерок за одну сессию!' },
        'ruthless': { i: '🌋', t: 'Извержение', d: 'Влепили 20 двоек за одну сессию.' },
        'rain_of_twos': { i: '🌧️', t: 'Дождь из Двоек', d: 'Поставили 15 двоек за сессию.' },
        'rain_of_fives': { i: '🌠', t: 'Звездопад', d: 'Поставили 30 пятерок за сессию.' },
        'yin_yang': { i: '☯️', t: 'Инь-Ян', d: 'Поставили ровно пять «5» и пять «2» за сессию.' },
        'slevin': { i: '🍀', t: 'Число Слевина', d: 'Выставили 77 оценок за сессию.' },
        'lucky_seven': { i: '🎰', t: 'Семерка', d: 'Поставили ровно 7 пятерок за сессию.' },
        'blackjack': { i: '🃏', t: 'Блэкджек', d: 'Поставили ровно 21 оценку за сессию.' },
        'perfectionist': { i: '✨', t: 'Перфекционист', d: 'Выставили оценку каждому в группе.' },
        'flawless': { i: '🛡️', t: 'Неуязвимые', d: 'Группа без единой буквы «Н» на экране.' },
        'plague': { i: '🦠', t: 'Эпидемия', d: 'Больше 10 пропусков (Н) на странице.' },
        'ghost_town': { i: '🏚️', t: 'Город-Призрак', d: 'На странице 30 или больше пропусков (Н).' },
        'hospital': { i: '🏥', t: 'Лазарет', d: 'На странице 20 или больше больничных (Б/У/П).' },
        'streak_5': { i: '🔥', t: 'В Огне', d: 'Заходили в МЭШ 5 дней подряд.' },
        'streak_10': { i: '☢️', t: 'МЭШ-зависимость', d: '10 дней подряд в журнале.' },
        'streak_30': { i: '📅', t: 'Месяц без Выходных', d: 'Заходили в МЭШ 30 дней подряд.' },
        'veteran': { i: '🎖️', t: 'Ветеран', d: 'Провели в МЭШ суммарно 30 разных дней.' },
        'hundred_days': { i: '🗓️', t: 'Сотня', d: 'Провели в МЭШ суммарно 100 разных дней.' },
        'half_year': { i: '⏳', t: 'Полгода Жизни', d: '180 дней в журнале. Вы живете здесь.' },
        'architect': { i: '🏗️', t: 'Архитектор', d: 'Использовали модуль перекраски.' },
        'picasso': { i: '🎨', t: 'Пикассо', d: 'Изменили множество элементов в Архитекторе.' },
        'hacker': { i: '💻', t: 'Хакер', d: 'Экстремально перестроили интерфейс Архитектором.' },
        'spy': { i: '🕵️‍♂️', t: 'Агент 007', d: 'Включили шпиона API.' },
        'turbo': { i: '⚡', t: 'Флэш', d: 'Включили ускорение анимаций.' },
        'ktp_master': { i: '📅', t: 'Повелитель Времени', d: 'Открыли страницу КТП.' },
        'absence_mode': { i: '👻', t: 'Охотник за Н-ками', d: 'Открыли режим отсутствия.' },
        'symbiote': { i: '🕷️', t: 'Симбиот', d: 'Выбрали Оценку с Весом 2.' },
        'weight_1': { i: '🪶', t: 'Легкотня', d: 'Выставили оценку с Весом 1.' },
        'all_5': { i: '⭐', t: 'Раздача Слонов', d: 'Использовали массовый режим "Всем 5".' },
        'all_2': { i: '🌩️', t: 'Гроза Курса', d: 'Использовали массовый режим "Всем 2".' },
        'col_picker': { i: '🗓️', t: 'Матрица Дат', d: 'Использовали выделение столбцов.' },
        'undo_master': { i: '⏪', t: 'Машина Времени', d: 'Удалили оценку Ластиком или Ctrl+Z.' },
        'undo_spam': { i: '♻️', t: 'Нерешительность', d: 'Отменили 5 оценок за одну сессию.' },
        'alt_eraser': { i: '🧹', t: 'Уборщик', d: 'Использовали скрытый Alt+Клик для удаления.' },
        'pdf_dossier': { i: '🖨️', t: 'Бюрократ', d: 'Сгенерировали PDF-досье на студента.' },
        'inspector': { i: '🔍', t: 'Инспектор', d: 'Скачали досье 5 раз за одну сессию.' },
        'fast_fingers': { i: '🖱️', t: 'Быстрые Пальцы', d: 'Поставили 5 оценок меньше чем за 3 сек.' },
        'speed_demon': { i: '🏎️', t: 'Спидраннер', d: 'Поставили 10 оценок быстрее 10 сек.' },
        'marathon': { i: '🏃', t: 'Марафонец', d: 'Провели на странице журнала больше 30 минут.' },
        'coffee': { i: '☕', t: 'Кофе-брейк', d: 'Отошли за чаем (неактивность 15 минут).' },
        'coffee_addict': { i: '☕☕', t: 'Кофеиновый Маньяк', d: 'Отошли от ПК 3 раза за сессию.' },
        'night_owl': { i: '🦉🦉', t: 'Сова 80лвл', d: 'Сделали 50 действий глубокой ночью.' },
        'ambassador': { i: '💎', t: 'Амбассадор', d: 'Собрали 10 достижений!' },
        'collector': { i: '🗃️', t: 'Коллекционер', d: 'Собрали 50 достижений.' },
        'hoarder': { i: '🏆', t: 'Барахольщик', d: 'Собрали 75 достижений.' },
        'true_legend': { i: '🌌', t: 'Истинная Легенда', d: 'Собрали ВСЕ 104 достижения! Вы прошли МЭШ.' }
    };

    function showVaporwaveToast(badge) {
        let container = document.getElementById('mesh-vw-toast-container');
        if (!container) {
            container = document.createElement('div'); container.id = 'mesh-vw-toast-container';
            container.style.cssText = 'position:fixed; bottom:30px; right:30px; z-index:9999999; display:flex; flex-direction:column; gap:15px; pointer-events:none;';
            document.body.appendChild(container);
        }
        const toast = document.createElement('div');
        toast.style.cssText = `background: linear-gradient(135deg, #2b1055 0%, #7597de 100%); border: 2px solid #ff71ce; box-shadow: 0 0 10px #ff71ce, 0 0 20px #01cdfe, inset 0 0 15px rgba(1, 205, 254, 0.3); color: #fff; padding: 15px 20px; border-radius: 4px; display: flex; align-items: center; gap: 15px; transform: translateX(150%); transition: transform 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.275); font-family: 'Courier New', monospace; min-width: 280px; position: relative; overflow: hidden;`;
        const scanlines = `<div style="position:absolute; top:0; left:0; right:0; bottom:0; background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06)); background-size: 100% 2px, 3px 100%; pointer-events:none;"></div>`;
        toast.innerHTML = scanlines + `<div style="font-size: 36px; filter: drop-shadow(0 0 8px #01cdfe); z-index:2;">${badge.i}</div><div style="display: flex; flex-direction: column; z-index:2;"><span style="font-size: 10px; color: #b967ff; font-weight: bold; text-shadow: 0 0 3px #b967ff; letter-spacing: 2px;">ACHIEVEMENT UNLOCKED</span><span style="font-size: 16px; font-weight: bold; color: #01cdfe; text-shadow: 0 0 5px #01cdfe; margin-bottom: 4px; letter-spacing: 1px; text-transform: uppercase;">${badge.t}</span><span style="font-size: 11px; color: #ffeb3b; line-height: 1.3;">${badge.d}</span></div>`;
        container.appendChild(toast);
        requestAnimationFrame(() => toast.style.transform = 'translateX(0)');
        setTimeout(() => { toast.style.transform = 'translateX(150%)'; setTimeout(() => toast.remove(), 600); }, 6000);
    }

    function unlockBadge(badgeId) {
        if (!stats.unlocked[badgeId] && BADGES[badgeId]) {
            stats.unlocked[badgeId] = true; saveStats(); showVaporwaveToast(BADGES[badgeId]);
            let count = Object.keys(stats.unlocked).length;
            if (count === 10) unlockBadge('ambassador');
            if (count === 50) unlockBadge('collector');
            if (count === 75) unlockBadge('hoarder');
            if (count === 104) unlockBadge('true_legend');
        }
    }

    function checkTimeBased() {
        const d = new Date(); const h = d.getHours(); const m = d.getMonth() + 1; const day = d.getDay(); const date = d.getDate();
        if (h >= 0 && h < 4) unlockBadge('owl');
        if (h >= 2 && h < 3) unlockBadge('vampire');
        if (h === 0) unlockBadge('nightmare');
        if (h >= 5 && h < 6) unlockBadge('sunrise');
        if (h >= 4 && h < 7) unlockBadge('early_bird');
        if (h >= 13 && h < 14) unlockBadge('lunch_break');
        if (h === 17) unlockBadge('tea_time');
        if (h >= 20) unlockBadge('overtime');
        if (day === 1 && h >= 8 && h <= 10) unlockBadge('monday');
        if (day === 0 || day === 6) unlockBadge('weekend_warrior');
        if (day === 5 && h >= 18) unlockBadge('friday_party');
        if (day === 5 && date === 13) unlockBadge('lucky_13');
        
        if (m === 12) unlockBadge('santa');
        if (m === 12 && date === 31) unlockBadge('new_year');
        if (m === 1 && date <= 8) unlockBadge('grinch');
        if (m === 1 && date === 25) unlockBadge('student_day');
        if (m === 2 && date === 14) unlockBadge('valentines');
        if (m === 2 && date === 23) unlockBadge('defender');
        if (m === 2 && date === 29) unlockBadge('leap_year');
        if (m === 3 && date === 8) unlockBadge('womens_day');
        if (m === 3 && date === 14) unlockBadge('pi_day');
        if (m === 4 && date === 1) unlockBadge('fool');
        if (m === 4 && date === 12) unlockBadge('cosmonaut');
        if (m === 3 || m === 4) unlockBadge('spring');
        if (m === 5 && date === 1) unlockBadge('labor_day');
        if (m === 5 && date === 4) unlockBadge('star_wars');
        if (m === 5 && date === 9) unlockBadge('victory');
        if (m === 5 && date <= 10) unlockBadge('may_bugs');
        if (m === 6 || m === 7 || m === 8) unlockBadge('summer');
        if (m === 9 && date === 1) unlockBadge('knowledge');
        if (m === 9) unlockBadge('autumn');
        if (m === 10 && date === 5) unlockBadge('teachers_day');
        if (m === 10 && date === 31) unlockBadge('halloween');
        
        const dateStr = d.toDateString();
        if (stats.lastDate !== dateStr) { 
            let lastD = new Date(stats.lastDate);
            let diffDays = Math.round((d - lastD) / (1000 * 60 * 60 * 24));
            if (diffDays === 1) stats.streak++; else stats.streak = 1;
            stats.totalDays++; stats.lastDate = dateStr; saveStats(); 
        }
        if (stats.streak >= 5) unlockBadge('streak_5');
        if (stats.streak >= 10) unlockBadge('streak_10');
        if (stats.streak >= 30) unlockBadge('streak_30');
        if (stats.totalDays >= 30) unlockBadge('veteran');
        if (stats.totalDays >= 100) unlockBadge('hundred_days');
        if (stats.totalDays >= 180) unlockBadge('half_year');
    }

    function checkTableBased() {
        if (!window.location.href.includes('journal')) return;
        setTimeout(() => {
            const cells = document.querySelectorAll('td, [role="gridcell"]');
            if (cells.length < 30) return;
            let hCount = 0; let bCount = 0;
            cells.forEach(c => { 
                let t = c.innerText.trim().toUpperCase();
                if (t === 'Н') hCount++; 
                if (t === 'Б' || t === 'У' || t === 'П') bCount++; 
            });
            if (hCount === 0) unlockBadge('flawless');
            if (hCount >= 10) unlockBadge('plague');
            if (hCount >= 30) unlockBadge('ghost_town');
            if (bCount >= 20) unlockBadge('hospital');
        }, 3000);
    }

    function checkFeatures() {
        if (window.location.href.includes('planning')) unlockBadge('ktp_master');
        let archRules = localStorage.getItem('MESH_ARCHITECT_RULES');
        if (archRules) {
            unlockBadge('architect');
            if (archRules.length > 50) unlockBadge('picasso');
            if (archRules.length > 200) unlockBadge('hacker');
        }
        if (sessionStorage.getItem('MESH_SPY_ENABLED') === 'true') unlockBadge('spy');
        chrome.storage.sync.get(['speedUp'], (data) => { if (data.speedUp) unlockBadge('turbo'); });
        const activeToggles = document.querySelectorAll('.ant-radio-button-wrapper-checked');
        for (let toggle of activeToggles) { if ((toggle.innerText || '').toLowerCase().includes('отсутстви')) unlockBadge('absence_mode'); }
    }

    let dossierCount = 0; let undoCount = 0;
    document.addEventListener('click', (e) => {
        if (e.target.id === 'mesh-pdf-btn') {
            unlockBadge('pdf_dossier'); dossierCount++;
            if(dossierCount >= 5) unlockBadge('inspector');
        }
        if (e.target.id === 'mesh-cp-start') unlockBadge('col_picker');
        if (e.target.closest && e.target.closest('.api-success-badge[title*="удалить"]')) {
            unlockBadge('undo_master'); undoCount++;
            if(undoCount >= 5) unlockBadge('undo_spam');
        }
        if (e.altKey && e.target.closest('[data-test-component*="markCell"]')) {
            unlockBadge('alt_eraser'); undoCount++;
            if(undoCount >= 5) unlockBadge('undo_spam');
        }
    });

    let sessionGrades = 0; let recentGrades = []; let speedTracker = []; let nightGrades = 0;
    function processNewGrade(gradeText) {
        stats.totalGrades++; sessionGrades++; saveStats();
        
        let h = new Date().getHours();
        if(h >= 0 && h < 4) { nightGrades++; if(nightGrades >= 50) unlockBadge('night_owl'); }

        speedTracker.push(Date.now());
        if (speedTracker.length > 10) speedTracker.shift();
        if (speedTracker.length === 5 && (speedTracker[4] - speedTracker[0] < 3000)) unlockBadge('fast_fingers');
        if (speedTracker.length === 10 && (speedTracker[9] - speedTracker[0] < 10000)) unlockBadge('speed_demon');

        if (stats.totalGrades >= 1) unlockBadge('first_blood');
        if (stats.totalGrades >= 10) unlockBadge('novice');
        if (stats.totalGrades >= 50) unlockBadge('pro');
        if (stats.totalGrades >= 100) unlockBadge('terminator');
        if (stats.totalGrades >= 500) unlockBadge('god');
        if (stats.totalGrades >= 1000) unlockBadge('cyborg');
        if (stats.totalGrades >= 5000) unlockBadge('matrix');
        if (stats.totalGrades >= 9000) unlockBadge('over_9000');
        if (stats.totalGrades === 777) unlockBadge('three_axes');
        if (stats.totalGrades === 666) unlockBadge('devil');

        if (sessionGrades === 7) unlockBadge('lucky_seven');
        if (sessionGrades === 15) unlockBadge('sniper');
        if (sessionGrades === 21) unlockBadge('blackjack');
        if (sessionGrades === 30) unlockBadge('machine_gun');
        if (sessionGrades === 77) unlockBadge('slevin');
        if (sessionGrades === 100) unlockBadge('centurion');
        if (sessionGrades === 500) unlockBadge('half_k');

        const val = parseInt(gradeText.replace(/[^\d]/g, ''));
        if (!isNaN(val)) {
            recentGrades.push(val); if (recentGrades.length > 10) recentGrades.shift();
            
            let fivesCount = recentGrades.filter(g => g === 5).length;
            let twosCount = recentGrades.filter(g => g === 2).length;
            
            if (sessionGrades >= 50 && fivesCount >= 50) unlockBadge('generous'); 
            if (sessionGrades >= 20 && twosCount >= 20) unlockBadge('ruthless');
            if (sessionGrades >= 30 && fivesCount >= 30) unlockBadge('rain_of_fives'); 
            if (sessionGrades >= 15 && twosCount >= 15) unlockBadge('rain_of_twos');
            
            const last3 = recentGrades.slice(-3); const last4 = recentGrades.slice(-4); const last5 = recentGrades.slice(-5); const last10 = recentGrades.slice(-10);
            
            if (last3.every(g => g === 2) && last3.length === 3) unlockBadge('executioner');
            if (last3.every(g => g === 3) && last3.length === 3) unlockBadge('hater');
            if (last10.every(g => g === 3) && last10.length === 10) unlockBadge('stability');
            if (last5.every(g => g === 4) && last5.length === 5) unlockBadge('lover');
            if (last5.every(g => g === 5) && last5.length === 5) unlockBadge('good_cop');
            
            if (last4.join('') === '2345') unlockBadge('straight_flush');
            if (last4.join('') === '5432') unlockBadge('stairway_down');
            if (last4.join('') === '5252') unlockBadge('rollercoaster');
            if (recentGrades.length >= 2 && recentGrades[recentGrades.length-2] === 2 && val === 5) unlockBadge('combo_breaker');
        }

        let gMode = document.getElementById('mesh-global-grade');
        if (gMode && gMode.value === '5') unlockBadge('all_5');
        if (gMode && gMode.value === '2') unlockBadge('all_2');
        let wMode = document.getElementById('mesh-global-weight');
        if (wMode && wMode.value === '1') unlockBadge('weight_1');
        if (wMode && wMode.value === '2') unlockBadge('symbiote');
    }

    const observer = new MutationObserver((mutations) => {
        mutations.forEach((m) => {
            m.addedNodes.forEach(node => {
                if (node.nodeType === 1 && node.classList) {
                    if (node.classList.contains('api-success-badge') && node.innerText.includes('✅')) processNewGrade(node.innerText);
                    if (node.innerText.includes('🗑️')) unlockBadge('undo_master');
                }
            });
        });
    });

    let idleTimer; let idleCount = 0;
    function resetIdle() {
        clearTimeout(idleTimer);
        idleTimer = setTimeout(() => { 
            unlockBadge('coffee'); 
            idleCount++; if(idleCount >= 3) unlockBadge('coffee_addict');
        }, 15 * 60 * 1000); 
    }
    document.addEventListener('mousemove', resetIdle);
    document.addEventListener('keypress', resetIdle);

    setTimeout(() => unlockBadge('marathon'), 30 * 60 * 1000); 
    setTimeout(() => {
        checkTimeBased(); checkTableBased(); checkFeatures(); resetIdle();
        observer.observe(document.body, { childList: true, subtree: true });
        setInterval(checkFeatures, 5000);
    }, 2000);
})();