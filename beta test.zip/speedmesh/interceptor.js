// ==========================================
// 🕵️‍♂️ MESH Interceptor: Сбор ключей и ID оценок
// ==========================================
(function() {
    console.log("🕵️‍♂️ MESH Interceptor: Модуль сбора данных запущен");
    const originalFetch = window.fetch;
    
    window.fetch = async function(...args) {
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url ? args[0].url : '');
        const response = await originalFetch.apply(this, args);
        
        // Перехватываем только GET-запросы к API МЭШ
        if (url.includes('/api/') && args[1]?.method !== 'POST' && args[1]?.method !== 'DELETE') {
            try {
                const clone = response.clone();
                clone.json().then(data => {
                    // 1. СБОР СИСТЕМНЫХ КЛЮЧЕЙ (Для отправки оценок)
                    let db = JSON.parse(window.sessionStorage.getItem('MESH_GLOBAL_DB') || '{"grade_system_ids":[], "control_forms":[]}');
                    let updatedDb = false;
                    let strData = JSON.stringify(data);
                    
                    let gsMatches = strData.match(/"grade_system_id":\s*(\d+)/g);
                    if (gsMatches) {
                        gsMatches.forEach(m => {
                            let id = parseInt(m.split(':')[1].trim());
                            if (!db.grade_system_ids.includes(id)) { db.grade_system_ids.push(id); updatedDb = true; }
                        });
                    }
                    let cfMatches = strData.match(/"control_form_id":\s*(\d+)/g);
                    if (cfMatches) {
                        cfMatches.forEach(m => {
                            let id = parseInt(m.split(':')[1].trim());
                            if (!db.control_forms.includes(id)) { db.control_forms.push(id); updatedDb = true; }
                        });
                    }
                    if (updatedDb) window.sessionStorage.setItem('MESH_GLOBAL_DB', JSON.stringify(db));

                    // 2. СБОР ID ОЦЕНОК (Для функции Ластика "Alt + Click")
                    let map = JSON.parse(window.sessionStorage.getItem('MESH_MARKS_MAP') || '{}');
                    let marksArray = [];
                    // МЭШ может возвращать данные в разных структурах
                    if (Array.isArray(data)) marksArray = data;
                    else if (data.items) marksArray = data.items;
                    else if (data.marks) marksArray = data.marks;
                    else if (data.payload) marksArray = data.payload;
                    
                    let updatedMap = false;
                    marksArray.forEach(m => {
                        if (m.id && m.student_profile_id && m.schedule_lesson_id) {
                            // Сохраняем связку: "ID Студента_ID Урока" = "ID Оценки"
                            map[`${m.student_profile_id}_${m.schedule_lesson_id}`] = m.id;
                            updatedMap = true;
                        }
                    });
                    if (updatedMap) window.sessionStorage.setItem('MESH_MARKS_MAP', JSON.stringify(map));

                }).catch(e=>{});
            } catch(e){}
        }
        return response;
    };
})();